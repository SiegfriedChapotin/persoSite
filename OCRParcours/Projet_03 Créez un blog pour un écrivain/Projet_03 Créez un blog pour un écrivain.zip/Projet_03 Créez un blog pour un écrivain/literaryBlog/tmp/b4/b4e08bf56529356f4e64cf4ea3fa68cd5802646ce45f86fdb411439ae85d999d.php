<?php

/* Layout/GenericLayout/header.html.twig */
class __TwigTemplate_df846b9aa78891eba6c62ab8bc47d85a72abb02da669960a8c2a7a92c0f78780 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<head>

    <!-- Required meta tags -->
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\" Roman, Billet simple pour l'Alaska\">
    <meta name=\"publisher\" content=\"Jean Forteroche\">
    <meta name=\"keywords\" lang=\"fr\"
          content=\"Jean-Forteroche, Forteroche, roman, littérature,  acteur, une main dans le dos, écrivain, français, french, literary, book\">
    <meta name=\"reply-to\" content=\"jean.Forteroche@gmail.com\">
    <meta name=\"category\" content=\" littérature\">
    <meta name=\"robots\" content=\"index, follow\">
    <meta name=\"distribution\" content=\"global\">
    <meta name=\"revisit-after\" content=\"15 day\">
    <meta name=\"author\" content=\"Jean Forteroche, acteur et écrivain\">
    <meta name=\"copyright\" content=\"Jean Forteroche\">
    <meta name=\"abstract\"
          content=\"Roman epistolaire et numérique, Billet simple pour l'Alaska est une oeuvre littéraire sur les questions climatiques\">

    <!-- Open Graph data -->
    <meta property=\"fb:app_id\" content=\"000000000000\"/>
    <meta property=\"og:title\" content=\"Jean Forteroche\"/>
    <meta property=\"og:type\" content=\"website\"/>
    <meta property=\"og:url\" content=\"http://projet03ocr.forterochejean.siegfriedchapotin.com/\"/>
    <meta property=\"og:image\"
          content=\"http://projet03ocr.forterochejean.siegfriedchapotin.com//public/img/billetsimplealaskaRS.png\"/>
    <meta property=\"og:description\"
          content=\"Roman epistolaire et numérique, Billet simple pour l'Alaska est une oeuvre littéraire sur les questions climatiques\"/>

    <!-- Twitter -->
    <meta name=\"twitter:card\" content=\"summary\"/>
    <meta name=\"twitter:title\" content=\"Roman, Billet simple pour l'Alaska\">
    <meta name=\"twitter:url\" content=\"http://projet03ocr.forterochejean.siegfriedchapotin.com/\">
    <meta name=\"twitter:description\"
          content=\"Roman epistolaire et numérique, Billet simple pour l'Alaska est une oeuvre littéraire sur les questions climatiques\">
    <meta name=\"twitter:image\"
          content=\"http://projet03ocr.forterochejean.siegfriedchapotin.com//public/img/billetsimplealaskaRS.png\">


    <title>Billet simple pour l'Alaska</title>

    <link rel=\"icon\" href=\"img/ico.png\">
    <link href=\"https://fonts.googleapis.com/css?family=Roboto\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Permanent+Marker\" rel=\"stylesheet\">

    <!-- Bootstrap core CSS -->
    <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\"
          integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">

    <!-- Custom styles for this Layout -->
    <link href=\"css/alaskaBook.css\" rel=\"stylesheet\">


</head>


<body>


<nav class=\"navbar navbar-expand-lg navbar-dark fixed-top bg-dark\">
    <a class=\"navbar-brand\" href=\"index.php\">Accueil</a>
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarsExample05\"
            aria-controls=\"navbarsExample05\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\"></span>
    </button>
    <div><h4><a class=\"nav-bar greenLink \" href=\"index.php?p=book\">Le livre</a></h4></div>

    <div class=\"collapse navbar-collapse\" id=\"navbarsExample05\">

        <ul class=\"navbar-nav mr-auto\">

            <li class=\"nav-item dropdown paddingRL \">
                <a class=\"btn btn-dark dropdown-toggle\" href=\"#\" role=\"button\" id=\"dropdownMenuLink\"
                   data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                    L'artiste sous toutes les coutures</a>
                <div class=\"dropdown-menu padding\" aria-labelledby=\"dropdown05\">
                    ";
        // line 79
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["showingsP"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["showings"]) {
            // line 80
            echo "                        <h4><a class=\"greenLink\"
                               href=\"index.php?p=showing_show&id=";
            // line 81
            echo twig_escape_filter($this->env, $this->getAttribute($context["showings"], "id", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["showings"], "title", []), "html", null, true);
            echo "</a></h4>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showings'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 83
        echo "                </div>
            </li>
            <li class=\"nav-item\">
                <a class=\"nav-link \" href=\"index.php?p=contact\">Me contacter</a>
            </li>

        </ul>


    </div>
</nav>
";
    }

    public function getTemplateName()
    {
        return "Layout/GenericLayout/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 83,  106 => 81,  103 => 80,  99 => 79,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"fr\">
<head>

    <!-- Required meta tags -->
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\" Roman, Billet simple pour l'Alaska\">
    <meta name=\"publisher\" content=\"Jean Forteroche\">
    <meta name=\"keywords\" lang=\"fr\"
          content=\"Jean-Forteroche, Forteroche, roman, littérature,  acteur, une main dans le dos, écrivain, français, french, literary, book\">
    <meta name=\"reply-to\" content=\"jean.Forteroche@gmail.com\">
    <meta name=\"category\" content=\" littérature\">
    <meta name=\"robots\" content=\"index, follow\">
    <meta name=\"distribution\" content=\"global\">
    <meta name=\"revisit-after\" content=\"15 day\">
    <meta name=\"author\" content=\"Jean Forteroche, acteur et écrivain\">
    <meta name=\"copyright\" content=\"Jean Forteroche\">
    <meta name=\"abstract\"
          content=\"Roman epistolaire et numérique, Billet simple pour l'Alaska est une oeuvre littéraire sur les questions climatiques\">

    <!-- Open Graph data -->
    <meta property=\"fb:app_id\" content=\"000000000000\"/>
    <meta property=\"og:title\" content=\"Jean Forteroche\"/>
    <meta property=\"og:type\" content=\"website\"/>
    <meta property=\"og:url\" content=\"http://projet03ocr.forterochejean.siegfriedchapotin.com/\"/>
    <meta property=\"og:image\"
          content=\"http://projet03ocr.forterochejean.siegfriedchapotin.com//public/img/billetsimplealaskaRS.png\"/>
    <meta property=\"og:description\"
          content=\"Roman epistolaire et numérique, Billet simple pour l'Alaska est une oeuvre littéraire sur les questions climatiques\"/>

    <!-- Twitter -->
    <meta name=\"twitter:card\" content=\"summary\"/>
    <meta name=\"twitter:title\" content=\"Roman, Billet simple pour l'Alaska\">
    <meta name=\"twitter:url\" content=\"http://projet03ocr.forterochejean.siegfriedchapotin.com/\">
    <meta name=\"twitter:description\"
          content=\"Roman epistolaire et numérique, Billet simple pour l'Alaska est une oeuvre littéraire sur les questions climatiques\">
    <meta name=\"twitter:image\"
          content=\"http://projet03ocr.forterochejean.siegfriedchapotin.com//public/img/billetsimplealaskaRS.png\">


    <title>Billet simple pour l'Alaska</title>

    <link rel=\"icon\" href=\"img/ico.png\">
    <link href=\"https://fonts.googleapis.com/css?family=Roboto\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Permanent+Marker\" rel=\"stylesheet\">

    <!-- Bootstrap core CSS -->
    <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\"
          integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">

    <!-- Custom styles for this Layout -->
    <link href=\"css/alaskaBook.css\" rel=\"stylesheet\">


</head>


<body>


<nav class=\"navbar navbar-expand-lg navbar-dark fixed-top bg-dark\">
    <a class=\"navbar-brand\" href=\"index.php\">Accueil</a>
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarsExample05\"
            aria-controls=\"navbarsExample05\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\"></span>
    </button>
    <div><h4><a class=\"nav-bar greenLink \" href=\"index.php?p=book\">Le livre</a></h4></div>

    <div class=\"collapse navbar-collapse\" id=\"navbarsExample05\">

        <ul class=\"navbar-nav mr-auto\">

            <li class=\"nav-item dropdown paddingRL \">
                <a class=\"btn btn-dark dropdown-toggle\" href=\"#\" role=\"button\" id=\"dropdownMenuLink\"
                   data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                    L'artiste sous toutes les coutures</a>
                <div class=\"dropdown-menu padding\" aria-labelledby=\"dropdown05\">
                    {% for showings in showingsP %}
                        <h4><a class=\"greenLink\"
                               href=\"index.php?p=showing_show&id={{ showings.id }}\">{{ showings.title }}</a></h4>
                    {% endfor %}
                </div>
            </li>
            <li class=\"nav-item\">
                <a class=\"nav-link \" href=\"index.php?p=contact\">Me contacter</a>
            </li>

        </ul>


    </div>
</nav>
", "Layout/GenericLayout/header.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Layout\\GenericLayout\\header.html.twig");
    }
}
