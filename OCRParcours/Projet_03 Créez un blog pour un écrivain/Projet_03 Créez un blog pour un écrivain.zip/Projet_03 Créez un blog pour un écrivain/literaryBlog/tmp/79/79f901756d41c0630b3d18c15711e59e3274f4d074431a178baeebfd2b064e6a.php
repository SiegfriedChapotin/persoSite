<?php

/* Posts/showheading.html.twig */
class __TwigTemplate_df6a92282fa49499c649e32e8c1e4ded6fdc71a7bf04605d10e93123d72553a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/GenericLayout/main.html.twig", "Posts/showheading.html.twig", 1);
        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/GenericLayout/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "

    <div class=\"shadow-lg p-5 mb-5 bg-gradient-warning rounded headingheight\">
        <h1>Billet simple pour l'Alaska</h1>
        <br/>
    </div>

    <div class=\"paddingtext\">

        <h2>";
        // line 13
        echo $this->getAttribute(($context["heading"] ?? null), "title", []);
        echo "</h2>
    </div>
    <div class=\"paddingtext\">
        <p>";
        // line 16
        echo $this->getAttribute(($context["heading"] ?? null), "text", []);
        echo "</p>

    </div>

";
    }

    public function getTemplateName()
    {
        return "Posts/showheading.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  48 => 16,  42 => 13,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Layout/GenericLayout/main.html.twig' %}

{% block content %}


    <div class=\"shadow-lg p-5 mb-5 bg-gradient-warning rounded headingheight\">
        <h1>Billet simple pour l'Alaska</h1>
        <br/>
    </div>

    <div class=\"paddingtext\">

        <h2>{{ heading.title|raw }}</h2>
    </div>
    <div class=\"paddingtext\">
        <p>{{ heading.text|raw }}</p>

    </div>

{% endblock %}", "Posts/showheading.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Posts\\showheading.html.twig");
    }
}
