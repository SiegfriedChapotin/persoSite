<?php

/* Layout/layoutdashboard.html.twig */
class __TwigTemplate_c6c8f87595d80232f3b22a1d84a85240d7c4a9b4d09bfb3ac3959e60ef62c83b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $this->loadTemplate("Layout/GenericLayout/header.html.twig", "Layout/layoutdashboard.html.twig", 1)->display($context);
        // line 2
        echo "
<div id=\"dashboard\" class=\"container-fluid\">
    <div class=\"row\">
        <nav class=\"col-md-2 d-none d-md-block bg-light sidebar\">

            <div class=\"sidebar-sticky\">
                <wbr/>
                <h4>Publications</h4>
                <br/>
                <ul class=\"nav flex-column mb-2\">
                    <li class=\"nav-item\">
                        <p></p>
                        <a href=\"index.php?p=Admin\"
                           data-toggle=\"tooltip\"
                           data-placement=\"top\"
                           title=\"Bureau\">
                            <span data-feather=\"home\"></span>
                            Bureau
                        </a>
                        </p>
                    </li>
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=writetext_admin\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\"Nouveau texte\">
                                <span data-feather=\"feather\"></span>
                                Nouveau texte
                            </a>
                        </p>
                    </li>
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=mail_Office\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\"Courriers\">
                                <span data-feather=\"mail\"></span>
                                Courriers
                            </a>
                        </p>
                    </li>
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=publication_Office\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\"Vos publications\">
                                <span data-feather=\"book-open\"></span>
                                Vos publications
                            </a>
                        </p>
                    </li>
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=comment_Office\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\"Commentaires\">
                                <span data-feather=\"users\"></span>
                                Commentaires
                            </a>
                        </p>
                    </li>
                </ul>

                <wbr/>
                <h4>Page d'accueil</h4>
                <br/>
                <ul class=\"nav flex-column mb-2\">
                    ";
        // line 73
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["texthome"]);
        foreach ($context['_seq'] as $context["_key"] => $context["texthome"]) {
            // line 74
            echo "                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=texthome_admin&id=";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($context["texthome"], "id", []), "html", null, true);
            echo "\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"";
            // line 79
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["texthome"], "title", [])), "html", null, true));
            echo "\">
                                    <span data-feather=\"file-text\"></span>
                                    ";
            // line 81
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["texthome"], "title", [])), "html", null, true));
            echo "
                                </a>
                            </p>
                        </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['texthome'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 86
        echo "
                    ";
        // line 87
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["headings"]);
        foreach ($context['_seq'] as $context["_key"] => $context["headings"]) {
            // line 88
            echo "                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=heading_admin&id=";
            // line 90
            echo twig_escape_filter($this->env, $this->getAttribute($context["headings"], "id", []), "html", null, true);
            echo "\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"";
            // line 93
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["headings"], "title", [])), "html", null, true));
            echo "\">
                                    <span data-feather=\"bookmark\"></span>
                                    ";
            // line 95
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["headings"], "title", [])), "html", null, true));
            echo "
                                </a>
                            </p>
                        </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['headings'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 100
        echo "
                </ul>

                <wbr/>
                <h4>Votre profil</h4>
                <br/>
                <ul class=\"nav flex-column mb-2\">
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=writeprofil_admin\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\" Nouveau profil\">
                                <span data-feather=\"feather\"></span>
                                Nouveau profil
                            </a>
                        </p>
                        <br/>
                    </li>
                    ";
        // line 119
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["showingsP"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["showings"]) {
            // line 120
            echo "                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=showing_admin&id=";
            // line 122
            echo twig_escape_filter($this->env, $this->getAttribute($context["showings"], "id", []), "html", null, true);
            echo "\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"";
            // line 125
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["showings"], "title", [])), "html", null, true));
            echo "\">
                                    <span data-feather=\"eye\"></span>
                                    ";
            // line 127
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["showings"], "title", [])), "html", null, true));
            echo "
                                </a>
                            </p>
                        </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showings'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 132
        echo "                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["showingsD"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["showings"]) {
            // line 133
            echo "                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=showing_admin&id=";
            // line 135
            echo twig_escape_filter($this->env, $this->getAttribute($context["showings"], "id", []), "html", null, true);
            echo "\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"";
            // line 138
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["showings"], "title", [])), "html", null, true));
            echo "\">
                                    <span data-feather=\"eye-off\"></span>
                                    ";
            // line 140
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["showings"], "title", [])), "html", null, true));
            echo "
                                    <br/> (brouillon)
                                </a>
                            </p>
                        </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showings'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 146
        echo "                </ul>

                <wbr/>
                <h4>Mentions légales</h4>
                <br/>
                <ul class=\"nav flex-column mb-2\">
                    ";
        // line 152
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["rgpd"]);
        foreach ($context['_seq'] as $context["_key"] => $context["rgpd"]) {
            // line 153
            echo "                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=rgpd_admin&id=";
            // line 155
            echo twig_escape_filter($this->env, $this->getAttribute($context["rgpd"], "id", []), "html", null, true);
            echo "\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"";
            // line 158
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["rgpd"], "title", [])), "html", null, true));
            echo "\">
                                    <span data-feather=\"info\"></span>
                                    ";
            // line 160
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["rgpd"], "title", [])), "html", null, true));
            echo "
                                </a>
                            </p>
                        </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rgpd'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 165
        echo "                </ul>
            </div>
        </nav>

        <main role=\"main\" class=\"col-md-9 ml-sm-auto col-lg-10 px-4\">
            <div class=\"row\">
                <div class=\"col-10\"></div>
                <div class=\"col-2 text-right\">
                    <a href=\"index.php?p=logout\" class=\"badge badge-dark\">Se déconnecter</a>
                </div>
            </div>
              ";
        // line 176
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(call_user_func_array($this->env->getFunction('FlashBag')->getCallable(), []));
        foreach ($context['_seq'] as $context["flashType"] => $context["flashMessages"]) {
            // line 177
            echo "            <div class=\"alert alert-";
            echo twig_escape_filter($this->env, $context["flashType"], "html", null, true);
            echo "\" role=\"alert\">
                ";
            // line 178
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["flashMessages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
                // line 179
                echo "
                    ";
                // line 180
                echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
                echo "
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 183
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['flashType'], $context['flashMessages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 184
        echo "
            <div>
                ";
        // line 186
        $this->displayBlock('textarea', $context, $blocks);
        // line 187
        echo "            </div>

        </main>
    </div>
</div>

";
        // line 193
        $this->loadTemplate("Layout/GenericLayout/footer.html.twig", "Layout/layoutdashboard.html.twig", 193)->display($context);
    }

    // line 186
    public function block_textarea($context, array $blocks = [])
    {
    }

    public function getTemplateName()
    {
        return "Layout/layoutdashboard.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  341 => 186,  337 => 193,  329 => 187,  327 => 186,  323 => 184,  317 => 183,  308 => 180,  305 => 179,  301 => 178,  296 => 177,  292 => 176,  279 => 165,  268 => 160,  263 => 158,  257 => 155,  253 => 153,  249 => 152,  241 => 146,  229 => 140,  224 => 138,  218 => 135,  214 => 133,  209 => 132,  198 => 127,  193 => 125,  187 => 122,  183 => 120,  179 => 119,  158 => 100,  147 => 95,  142 => 93,  136 => 90,  132 => 88,  128 => 87,  125 => 86,  114 => 81,  109 => 79,  103 => 76,  99 => 74,  95 => 73,  22 => 2,  20 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include  \"Layout/GenericLayout/header.html.twig\" %}

<div id=\"dashboard\" class=\"container-fluid\">
    <div class=\"row\">
        <nav class=\"col-md-2 d-none d-md-block bg-light sidebar\">

            <div class=\"sidebar-sticky\">
                <wbr/>
                <h4>Publications</h4>
                <br/>
                <ul class=\"nav flex-column mb-2\">
                    <li class=\"nav-item\">
                        <p></p>
                        <a href=\"index.php?p=Admin\"
                           data-toggle=\"tooltip\"
                           data-placement=\"top\"
                           title=\"Bureau\">
                            <span data-feather=\"home\"></span>
                            Bureau
                        </a>
                        </p>
                    </li>
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=writetext_admin\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\"Nouveau texte\">
                                <span data-feather=\"feather\"></span>
                                Nouveau texte
                            </a>
                        </p>
                    </li>
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=mail_Office\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\"Courriers\">
                                <span data-feather=\"mail\"></span>
                                Courriers
                            </a>
                        </p>
                    </li>
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=publication_Office\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\"Vos publications\">
                                <span data-feather=\"book-open\"></span>
                                Vos publications
                            </a>
                        </p>
                    </li>
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=comment_Office\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\"Commentaires\">
                                <span data-feather=\"users\"></span>
                                Commentaires
                            </a>
                        </p>
                    </li>
                </ul>

                <wbr/>
                <h4>Page d'accueil</h4>
                <br/>
                <ul class=\"nav flex-column mb-2\">
                    {% for texthome in texthome %}
                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=texthome_admin&id={{ texthome.id }}\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"{{ texthome.title|striptags | nl2br }}\">
                                    <span data-feather=\"file-text\"></span>
                                    {{ texthome.title|striptags | nl2br }}
                                </a>
                            </p>
                        </li>
                    {% endfor %}

                    {% for headings in headings %}
                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=heading_admin&id={{ headings.id }}\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"{{ headings.title|striptags | nl2br }}\">
                                    <span data-feather=\"bookmark\"></span>
                                    {{ headings.title|striptags | nl2br }}
                                </a>
                            </p>
                        </li>
                    {% endfor %}

                </ul>

                <wbr/>
                <h4>Votre profil</h4>
                <br/>
                <ul class=\"nav flex-column mb-2\">
                    <li class=\"nav-item\">
                        <p>
                            <a href=\"index.php?p=writeprofil_admin\"
                               data-toggle=\"tooltip\"
                               data-placement=\"top\"
                               title=\" Nouveau profil\">
                                <span data-feather=\"feather\"></span>
                                Nouveau profil
                            </a>
                        </p>
                        <br/>
                    </li>
                    {% for showings in showingsP %}
                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=showing_admin&id={{ showings.id }}\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"{{ showings.title|striptags | nl2br }}\">
                                    <span data-feather=\"eye\"></span>
                                    {{ showings.title|striptags | nl2br }}
                                </a>
                            </p>
                        </li>
                    {% endfor %}
                    {% for showings in showingsD %}
                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=showing_admin&id={{ showings.id }}\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"{{ showings.title|striptags | nl2br }}\">
                                    <span data-feather=\"eye-off\"></span>
                                    {{ showings.title|striptags | nl2br }}
                                    <br/> (brouillon)
                                </a>
                            </p>
                        </li>
                    {% endfor %}
                </ul>

                <wbr/>
                <h4>Mentions légales</h4>
                <br/>
                <ul class=\"nav flex-column mb-2\">
                    {% for rgpd in rgpd %}
                        <li class=\"nav-item\">
                            <p>
                                <a href=\"index.php?p=rgpd_admin&id={{ rgpd.id }}\"
                                   data-toggle=\"tooltip\"
                                   data-placement=\"top\"
                                   title=\"{{ rgpd.title|striptags | nl2br }}\">
                                    <span data-feather=\"info\"></span>
                                    {{ rgpd.title|striptags | nl2br }}
                                </a>
                            </p>
                        </li>
                    {% endfor %}
                </ul>
            </div>
        </nav>

        <main role=\"main\" class=\"col-md-9 ml-sm-auto col-lg-10 px-4\">
            <div class=\"row\">
                <div class=\"col-10\"></div>
                <div class=\"col-2 text-right\">
                    <a href=\"index.php?p=logout\" class=\"badge badge-dark\">Se déconnecter</a>
                </div>
            </div>
              {% for flashType,flashMessages in FlashBag() %}
            <div class=\"alert alert-{{ flashType }}\" role=\"alert\">
                {% for flashMessage in flashMessages %}

                    {{ flashMessage }}
                    </div>
                {% endfor %}
            {% endfor %}

            <div>
                {% block textarea %}{% endblock %}
            </div>

        </main>
    </div>
</div>

{% include  \"Layout/GenericLayout/footer.html.twig\" %}", "Layout/layoutdashboard.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Layout\\layoutdashboard.html.twig");
    }
}
