<?php

/* Admin/Office/officePublication.html.twig */
class __TwigTemplate_53ced8617062c743755ec704b41415aec08fbef9aaee892b9e1c1abbd3de8817 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/Office/officePublication.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_textarea($context, array $blocks = [])
    {
        // line 4
        echo "
    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Votre publications</h1>
    </div>

    <div class=\"col-12 shadow-lg p-2 mb-5 p-lg-5\">
        <nav>
            <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
                <a class=\"nav-item nav-link active\" id=\"nav-news-tab\" data-toggle=\"tab\" href=\"#nav-news\" role=\"tab\"
                   aria-controls=\"nav-news\" aria-selected=\"true\"><h3>Vos brouillons</h3></a>
                <a class=\"nav-item nav-link\" id=\"nav-archives-tab\" data-toggle=\"tab\" href=\"#nav-archives\" role=\"tab\"
                   aria-controls=\"nav-archives\" aria-selected=\"false\"><h3>Archives</h3></a>
            </div>
        </nav>
        <div class=\"tab-content\" id=\"nav-tabContent\">
            <div class=\"tab-pane fade show active\" id=\"nav-news\" role=\"tabpanel\" aria-labelledby=\"nav-news-tab\">
                <div id=\"accordion\">
                    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["publicationoffice"]);
        foreach ($context['_seq'] as $context["_key"] => $context["publicationoffice"]) {
            // line 23
            echo "                        <div>
                            <div class=\"card-header\" id=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationoffice"], "id", []), "html", null, true);
            echo "\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-5 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\">";
            // line 27
            echo $this->getAttribute($context["publicationoffice"], "title", []);
            echo "</a>
                                    </div>
                                    <div class=\"col col-sm-5  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-info font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationoffice"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                                aria-controls=\"collapse";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationoffice"], "id", []), "html", null, true);
            echo "\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationoffice"], "id", []), "html", null, true);
            echo "\" class=\"collapse\"
                                 aria-labelledby=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationoffice"], "id", []), "html", null, true);
            echo "\"
                                 data-parent=\"#accordion\">
                                <div class=\"container-fluide\">
                                    <form method=\"post\">
                                        <div class=\"row\">
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                                <div class=\"card-body\">
                                                    <p class=\"text-right font-weight-bold\">
                                                        <a class=\"paddingRL\"> ";
            // line 48
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["publicationoffice"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</a>
                                                    </p>
                                                    <p class=\"paddingtext paper\">";
            // line 50
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["publicationoffice"], "text", [])), "html", null, true));
            echo "</p>
                                                </div>
                                            </div>
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3\">
                                                <div class=\"paddingtext row  \">
                                                    <div class=\"col-12 paddingRL\">
                                                        <a href=\"index.php?p=posts_admin&id=";
            // line 56
            echo nl2br($this->getAttribute(($context["book"] ?? null), "id", []));
            echo "\">
                                                            <button type=\"submit\"
                                                                    class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                                                    name=\"postModify\"
                                                                    value=\"";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationoffice"], "id", []), "html", null, true);
            echo "\">
                                                                <a class=\" paddingRL\">Modifier</a>
                                                                <i data-feather=\"edit-2\"></i>
                                                            </button>
                                                        </a>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-bg btn-success font-weight-bold \"
                                                                name=\"classify\"
                                                                value=\"";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationoffice"], "id", []), "html", null, true);
            echo "\">
                                                            <a class=\" paddingRL\">Publier</a>
                                                            <i data-feather=\"check\"></i>
                                                        </button>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                                name=\"delete\"
                                                                value=\"";
            // line 79
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationoffice"], "id", []), "html", null, true);
            echo "\">
                                                            <a class=\" paddingRL\"> Supprimer</a>
                                                            <i data-feather=\"delete\"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['publicationoffice'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 92
        echo "                </div>
            </div>
            <div class=\"tab-pane fade active\" id=\"nav-archives\" role=\"tabpanel\" aria-labelledby=\"nav-archives-tab\">
                <div id=\"accordionC\">
                    ";
        // line 96
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["publicationclass"]);
        foreach ($context['_seq'] as $context["_key"] => $context["publicationclass"]) {
            // line 97
            echo "                        <div>
                            <div class=\"card-header\" id=\"";
            // line 98
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationclass"], "id", []), "html", null, true);
            echo "\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col-8 col-lg-10 paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 101
            echo $this->getAttribute($context["publicationclass"], "title", []);
            echo "</a>
                                    </div>
                                    <div class=\"col-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-info font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse";
            // line 106
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationclass"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                                aria-controls=\"collapse";
            // line 107
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationclass"], "id", []), "html", null, true);
            echo "\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse";
            // line 113
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationclass"], "id", []), "html", null, true);
            echo "\" class=\"collapse\"
                                 aria-labelledby=\"";
            // line 114
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationclass"], "id", []), "html", null, true);
            echo "\"
                                 data-parent=\"#accordionC\">
                                <div class=\"container-fluide\">
                                    <div class=\" paddingtext row\">
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                            <div class=\"row\">
                                                <p class=\"paddingtext\">";
            // line 120
            echo $this->getAttribute($context["publicationclass"], "title", []);
            echo "</p>
                                                <p class=\"paddingtext\">Chapitre : ";
            // line 121
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationclass"], "chapter", []), "html", null, true);
            echo "</p>
                                                <p class=\"paddingtext\">";
            // line 122
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["publicationclass"], "text", [])), "html", null, true));
            echo "</p>
                                            </div>
                                            <div class=\"row\">
                                                <a class=\"paddingRL\"> ";
            // line 125
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["publicationclass"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</a>
                                            </div>
                                        </div>
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3\">
                                            <form method=\"post\">
                                                <div class=\"paddingtext row \">
                                                    <div class=\"col-12 paddingRL\">
                                                        <a href=\"index.php?p=posts_admin&id=";
            // line 132
            echo nl2br(twig_escape_filter($this->env, $this->getAttribute(($context["book"] ?? null), "id", []), "html", null, true));
            echo "\">
                                                            <button type=\"submit\"
                                                                    class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                                                    name=\"postModify\"
                                                                    value=\"";
            // line 136
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationclass"], "id", []), "html", null, true);
            echo "\">
                                                                <a class=\" paddingRL\">Modifier</a>
                                                                <i data-feather=\"edit-2\"></i>
                                                            </button>
                                                        </a>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                                name=\"delete\"
                                                                value=\"";
            // line 146
            echo twig_escape_filter($this->env, $this->getAttribute($context["publicationclass"], "id", []), "html", null, true);
            echo "\">
                                                            <a class=\" paddingRL\"> Supprimer</a>
                                                            <i data-feather=\"delete\"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['publicationclass'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 159
        echo "                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "Admin/Office/officePublication.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  281 => 159,  262 => 146,  249 => 136,  242 => 132,  232 => 125,  226 => 122,  222 => 121,  218 => 120,  209 => 114,  205 => 113,  196 => 107,  192 => 106,  184 => 101,  178 => 98,  175 => 97,  171 => 96,  165 => 92,  146 => 79,  134 => 70,  121 => 60,  114 => 56,  105 => 50,  100 => 48,  89 => 40,  85 => 39,  76 => 33,  72 => 32,  64 => 27,  58 => 24,  55 => 23,  51 => 22,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}

{% block textarea %}

    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Votre publications</h1>
    </div>

    <div class=\"col-12 shadow-lg p-2 mb-5 p-lg-5\">
        <nav>
            <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
                <a class=\"nav-item nav-link active\" id=\"nav-news-tab\" data-toggle=\"tab\" href=\"#nav-news\" role=\"tab\"
                   aria-controls=\"nav-news\" aria-selected=\"true\"><h3>Vos brouillons</h3></a>
                <a class=\"nav-item nav-link\" id=\"nav-archives-tab\" data-toggle=\"tab\" href=\"#nav-archives\" role=\"tab\"
                   aria-controls=\"nav-archives\" aria-selected=\"false\"><h3>Archives</h3></a>
            </div>
        </nav>
        <div class=\"tab-content\" id=\"nav-tabContent\">
            <div class=\"tab-pane fade show active\" id=\"nav-news\" role=\"tabpanel\" aria-labelledby=\"nav-news-tab\">
                <div id=\"accordion\">
                    {% for publicationoffice in publicationoffice %}
                        <div>
                            <div class=\"card-header\" id=\"{{ publicationoffice.id }}\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-5 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\">{{ publicationoffice.title|raw }}</a>
                                    </div>
                                    <div class=\"col col-sm-5  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-info font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse{{ publicationoffice.id }}\" aria-expanded=\"true\"
                                                aria-controls=\"collapse{{ publicationoffice.id }}\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse{{ publicationoffice.id }}\" class=\"collapse\"
                                 aria-labelledby=\"{{ publicationoffice.id }}\"
                                 data-parent=\"#accordion\">
                                <div class=\"container-fluide\">
                                    <form method=\"post\">
                                        <div class=\"row\">
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                                <div class=\"card-body\">
                                                    <p class=\"text-right font-weight-bold\">
                                                        <a class=\"paddingRL\"> {{ publicationoffice.date|date_modify ( \"+1 day\" )| date ( \"m/d/Y\"  ) }}</a>
                                                    </p>
                                                    <p class=\"paddingtext paper\">{{ publicationoffice.text|striptags|nl2br }}</p>
                                                </div>
                                            </div>
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3\">
                                                <div class=\"paddingtext row  \">
                                                    <div class=\"col-12 paddingRL\">
                                                        <a href=\"index.php?p=posts_admin&id={{ book.id |raw|nl2br }}\">
                                                            <button type=\"submit\"
                                                                    class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                                                    name=\"postModify\"
                                                                    value=\"{{ publicationoffice.id }}\">
                                                                <a class=\" paddingRL\">Modifier</a>
                                                                <i data-feather=\"edit-2\"></i>
                                                            </button>
                                                        </a>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-bg btn-success font-weight-bold \"
                                                                name=\"classify\"
                                                                value=\"{{ publicationoffice.id }}\">
                                                            <a class=\" paddingRL\">Publier</a>
                                                            <i data-feather=\"check\"></i>
                                                        </button>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                                name=\"delete\"
                                                                value=\"{{ publicationoffice.id }}\">
                                                            <a class=\" paddingRL\"> Supprimer</a>
                                                            <i data-feather=\"delete\"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
            <div class=\"tab-pane fade active\" id=\"nav-archives\" role=\"tabpanel\" aria-labelledby=\"nav-archives-tab\">
                <div id=\"accordionC\">
                    {% for publicationclass in publicationclass %}
                        <div>
                            <div class=\"card-header\" id=\"{{ publicationclass.id }}\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col-8 col-lg-10 paddingtext\">
                                        <a class=\"paddingRL\"> {{ publicationclass.title|raw }}</a>
                                    </div>
                                    <div class=\"col-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-info font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse{{ publicationclass.id }}\" aria-expanded=\"true\"
                                                aria-controls=\"collapse{{ publicationclass.id }}\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse{{ publicationclass.id }}\" class=\"collapse\"
                                 aria-labelledby=\"{{ publicationclass.id }}\"
                                 data-parent=\"#accordionC\">
                                <div class=\"container-fluide\">
                                    <div class=\" paddingtext row\">
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                            <div class=\"row\">
                                                <p class=\"paddingtext\">{{ publicationclass.title|raw }}</p>
                                                <p class=\"paddingtext\">Chapitre : {{ publicationclass.chapter }}</p>
                                                <p class=\"paddingtext\">{{ publicationclass.text|striptags|nl2br }}</p>
                                            </div>
                                            <div class=\"row\">
                                                <a class=\"paddingRL\"> {{ publicationclass.date| date_modify ( \"+1 day\" )| date ( \"m/d/Y\" ) }}</a>
                                            </div>
                                        </div>
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3\">
                                            <form method=\"post\">
                                                <div class=\"paddingtext row \">
                                                    <div class=\"col-12 paddingRL\">
                                                        <a href=\"index.php?p=posts_admin&id={{ book.id |nl2br }}\">
                                                            <button type=\"submit\"
                                                                    class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                                                    name=\"postModify\"
                                                                    value=\"{{ publicationclass.id }}\">
                                                                <a class=\" paddingRL\">Modifier</a>
                                                                <i data-feather=\"edit-2\"></i>
                                                            </button>
                                                        </a>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                                name=\"delete\"
                                                                value=\"{{ publicationclass.id }}\">
                                                            <a class=\" paddingRL\"> Supprimer</a>
                                                            <i data-feather=\"delete\"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "Admin/Office/officePublication.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Admin\\Office\\officePublication.html.twig");
    }
}
