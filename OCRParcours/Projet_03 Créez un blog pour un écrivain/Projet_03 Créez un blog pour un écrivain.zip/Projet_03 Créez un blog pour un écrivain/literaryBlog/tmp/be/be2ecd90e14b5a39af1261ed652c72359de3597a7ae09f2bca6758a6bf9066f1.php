<?php

/* Layout/GenericLayout/header.html.twig */
class __TwigTemplate_0f668d3edec9e5eed25078d499158fe8c5b35c8d6025cb4c643180a2ad65ff4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\" Roman, Billet simple pour l'Alaska\">
    <meta name=\"author\" content=\"Jean Forteroche, acteur et écrivain\">
    <link rel=\"icon\" href=\"img/ico.png\">

    <title>Billet simple pour l'Alaska</title>
    <link href=\"https://fonts.googleapis.com/css?family=Roboto\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Permanent+Marker\" rel=\"stylesheet\">
    <!-- Bootstrap core CSS -->
    <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\"
          integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">

    Layout
    <link href=\"css/LayoutBook.css\" rel=\"stylesheet\">


</head>


<body>


<nav class=\"navbar navbar-expand-lg navbar-dark fixed-top bg-dark\">
    <a class=\"navbar-brand\" href=\"index.php\">Accueil</a>
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarsExample05\"
            aria-controls=\"navbarsExample05\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\"></span>
    </button>
    <div><h4><a class=\"nav-bar greenLink \" href=\"index.php?p=book\">Le livre</a></h4></div>

    <div class=\"collapse navbar-collapse\" id=\"navbarsExample05\">

        <ul class=\"navbar-nav mr-auto\">

            <li class=\"nav-item dropdown paddingRL \">
                <a class=\"btn btn-dark dropdown-toggle\" href=\"#\" role=\"button\" id=\"dropdownMenuLink\"
                   data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                    L'artiste sous toutes les coutures</a>
                <div class=\"dropdown-menu padding\" aria-labelledby=\"dropdown05\">
                    ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["showingsP"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["showings"]) {
            // line 45
            echo "                        <h4><a class=\"greenLink\"
                               href=\"index.php?p=showing_show&id=";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["showings"], "id", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["showings"], "title", []), "html", null, true);
            echo "</a></h4>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showings'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "                </div>
            </li>
            <li class=\"nav-item\">
                <a class=\"nav-link \" href=\"index.php?p=contact\">Me contacter</a>
            </li>

        </ul>

        <form class=\"form-inline my-2 my-md-0\">
            <input class=\"form-control\" type=\"text\" placeholder=\"Rechercher\">
        </form>
    </div>
</nav>
";
    }

    public function getTemplateName()
    {
        return "layout/GenericLayout/header.htmlLayout;
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 48,  71 => 46,  68 => 45,  64 => 44,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\" Roman, Billet simple pour l'Alaska\">
    <meta name=\"author\" content=\"Jean Forteroche, acteur et écrivain\">
    <link rel=\"icon\" href=\"img/ico.png\">

    <title>Billet simple pour l'Alaska</title>
    <link href=\"https://fonts.googleapis.com/css?family=Roboto\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Permanent+Marker\" rel=\"stylesheet\">
    <!-- Bootstrap core CSS -->
    <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\"
          integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">

    <!-- Custom styles for this layout -->
    <link href=\"css/LayoutBook.css\" rel=\"stylesheet\">


</head>


<body>


<nav class=\"navbar navbar-expand-lg navbar-dark fixed-top bg-dark\">
    <a class=\"navbar-brand\" href=\"index.php\">Accueil</a>
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarsExample05\"
            aria-controls=\"navbarsExample05\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\"></span>
    </button>
    <div><h4><a class=\"nav-bar greenLink \" href=\"index.php?p=book\">Le livre</a></h4></div>

    <div class=\"collapse navbar-collapse\" id=\"navbarsExample05\">

        <ul class=\"navbar-nav mr-auto\">

            <li class=\"nav-item dropdown paddingRL \">
                <a class=\"btn btn-dark dropdown-toggle\" href=\"#\" role=\"button\" id=\"dropdownMenuLink\"
                   data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                    L'artiste sous toutes les coutures</a>
                <div class=\"dropdown-menu padding\" aria-labelledby=\"dropdown05\">
                    {% for showings in showingsP %}
                        <h4><a class=\"greenLink\"
                               href=\"index.php?p=showing_show&id={{ showings.id }}\">{{ showings.title }}</a></h4>
                    {% endfor %}
                </div>
            </li>
            <li class=\"nav-item\">
                <a class=\"nav-link \" href=\"index.php?p=contact\">Me contacter</a>
            </li>

        </ul>

        <form class=\"form-inline my-2 my-md-0\">
            <input class=\"form-control\" type=\"text\" placeholder=\"Rechercher\">
        </form>
    </div>
</nav>
", "layout/GenericLayout/header.htmlLayout, "C:\\wamp64\\www\\literaryBlog\\app\\Views\\layout\\GenericLayout\\header.htLayoutg");
    }
}
