<?php

/* Layout/GenericLayout/main.html.twig */
class __TwigTemplate_7d18683ab446b4672b26fa3f82e6d02e9ed19fb25052af2fedbab07b0f93d7f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'comment' => [$this, 'block_comment'],
            'writecomment' => [$this, 'block_writecomment'],
            'contact' => [$this, 'block_contact'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $this->loadTemplate("Layout/GenericLayout/header.html.twig", "Layout/GenericLayout/main.html.twig", 1)->display($context);
        // line 2
        echo "
<main role=\"main\">

    <div class=\"container paddingPage\">


        ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(call_user_func_array($this->env->getFunction('FlashBag')->getCallable(), []));
        foreach ($context['_seq'] as $context["flashType"] => $context["flashMessages"]) {
            // line 9
            echo "        <div class=\"alert alert-";
            echo twig_escape_filter($this->env, $context["flashType"], "html", null, true);
            echo "\" role=\"alert\">
            ";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["flashMessages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
                // line 11
                echo "
                ";
                // line 12
                echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
                echo "
                </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 15
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['flashType'], $context['flashMessages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "
        ";
        // line 17
        $this->displayBlock('content', $context, $blocks);
        // line 18
        echo "
        ";
        // line 19
        $this->displayBlock('comment', $context, $blocks);
        // line 20
        echo "
        ";
        // line 21
        $this->displayBlock('writecomment', $context, $blocks);
        // line 22
        echo "
        ";
        // line 23
        $this->displayBlock('contact', $context, $blocks);
        // line 24
        echo "
    </div>

</main>

";
        // line 29
        $this->loadTemplate("Layout/GenericLayout/footer.html.twig", "Layout/GenericLayout/main.html.twig", 29)->display($context);
        // line 30
        echo "

";
    }

    // line 17
    public function block_content($context, array $blocks = [])
    {
    }

    // line 19
    public function block_comment($context, array $blocks = [])
    {
    }

    // line 21
    public function block_writecomment($context, array $blocks = [])
    {
    }

    // line 23
    public function block_contact($context, array $blocks = [])
    {
    }

    public function getTemplateName()
    {
        return "Layout/GenericLayout/main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 23,  109 => 21,  104 => 19,  99 => 17,  93 => 30,  91 => 29,  84 => 24,  82 => 23,  79 => 22,  77 => 21,  74 => 20,  72 => 19,  69 => 18,  67 => 17,  64 => 16,  58 => 15,  49 => 12,  46 => 11,  42 => 10,  37 => 9,  33 => 8,  25 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include  \"Layout/GenericLayout/header.html.twig\" %}

<main role=\"main\">

    <div class=\"container paddingPage\">


        {% for flashType,flashMessages in FlashBag() %}
        <div class=\"alert alert-{{ flashType }}\" role=\"alert\">
            {% for flashMessage in flashMessages %}

                {{ flashMessage }}
                </div>
            {% endfor %}
        {% endfor %}

        {% block content %}{% endblock %}

        {% block comment %}{% endblock %}

        {% block writecomment %}{% endblock %}

        {% block contact %}{% endblock %}

    </div>

</main>

{% include  \"Layout/GenericLayout/footer.html.twig\" %}


", "Layout/GenericLayout/main.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Layout\\GenericLayout\\main.html.twig");
    }
}
