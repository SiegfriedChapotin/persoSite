<?php

/* Admin/dashboard.html.twig */
class __TwigTemplate_82961e659b727b5c60848fa155b18eda15d2f86995ec11bcf2587a6f59f0fff2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/dashboard.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_textarea($context, array $blocks = [])
    {
        // line 6
        echo "
    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Bureau</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-lg-6 col-md-12  \">
            <div class=\"row padding\">
                <div class=\"col-12 shadow-lg p-2 mb-3 \">
                    <h3>Vos courriers</h3>
                </div>
                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-sm\">
                        <thead>
                        <tr class=\"text-white bg-success\">
                            <th class=\"width20\">Nom</th>
                            <th>Courriel</th>
                            <th class=\"width10\">Lire</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["mail"]);
        foreach ($context['_seq'] as $context["_key"] => $context["mail"]) {
            // line 29
            echo "                            <tr>
                                <td>";
            // line 30
            echo $this->getAttribute($context["mail"], "name", []);
            echo "</td>
                                <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_truncate_filter($this->env, $this->getAttribute($context["mail"], "title", []), 50), "html", null, true);
            echo "</td>
                                <td>
                                    <a href=\"index.php?p=mail_Office\">
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-info font-weight-bold \"
                                                name=\"MailLire\"
                                                value=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute(($context["commentreport"] ?? null), "id", []), "html", null, true);
            echo "\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Voir\">
                                            <i data-feather=\"eye\"></i>
                                        </button>
                                    </a>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mail'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <div class=\"col-lg-6 col-md-12\">
            <div class=\"row padding\">
                <div class=\"col-12 shadow-lg p-2 mb-3 \">
                    <h3>Vos Publications en cours de rédaction</h3>
                </div>

                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-sm\">
                        <thead>
                        <tr class=\"text-white bg-info\">
                            <th>Titre</th>
                            <th>Date</th>
                            <th class=\"width10\">Voir</th>
                            <th class=\"width10\">Modif</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["chapitres"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 69
            echo "
                            <tr>
                                <td>";
            // line 71
            echo $this->getAttribute($context["book"], "title", []);
            echo "</td>
                                <td>";
            // line 72
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["book"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</td>
                                <td>
                                    <a href=\"index.php?p=publication_Office\">
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-info font-weight-bold \"
                                                name=\"postLire\"
                                                value=\"";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute(($context["commentreport"] ?? null), "id", []), "html", null, true);
            echo "\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Voir\">
                                            <i data-feather=\"eye\"></i>
                                        </button>
                                    </a>
                                </td>
                                <td>
                                    <a href=\"index.php?p=posts_admin&id=";
            // line 85
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", []), "html", null, true);
            echo "\">
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                                name=\"postModify\"
                                                value=\"";
            // line 89
            echo twig_escape_filter($this->env, $this->getAttribute(($context["commentreport"] ?? null), "id", []), "html", null, true);
            echo "\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Modifier\">
                                            <i data-feather=\"edit-2\"></i>
                                        </button>
                                    </a>
                                </td>
                            </tr>

                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <br/>
    <div class=\"row\">
        <div class=\"col-lg-6 col-md-12 \">
            <div class=\"row padding\">
                <div class=\"col-12 shadow-lg p-2 mb-3 \">
                    <h3>Les derniers commentaires</h3>
                </div>

                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-sm\">
                        <thead>
                        <tr class=\"text-white bg-warning \">
                            <th class=\"width20\">Pseudo</th>
                            <th>Commentaires</th>
                            <th class=\"width10\">Lire</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 122
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["comment"]);
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 123
            echo "
                            <tr>
                                <td>";
            // line 125
            echo $this->getAttribute($context["comment"], "pseudo", []);
            echo "</td>
                                <td>";
            // line 126
            echo twig_escape_filter($this->env, twig_truncate_filter($this->env, $this->getAttribute($context["comment"], "comment", []), 100), "html", null, true);
            echo "</td>
                                <td>
                                    <a href=\"index.php?p=comment_Office\" >
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-info font-weight-bold \"
                                                name=\"commentLire\"
                                                value=\"";
            // line 132
            echo twig_escape_filter($this->env, $this->getAttribute(($context["commentreport"] ?? null), "id", []), "html", null, true);
            echo "\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"voir\">
                                            <i data-feather=\"eye\"></i>
                                        </button>
                                    </a>
                                </td>
                            </tr>

                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 141
        echo "
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class=\"col-lg-6 col-md-12\">
            <div class=\"row padding\">
                <div class=\"col-12 shadow-lg p-2 mb-3 \">
                    <h3>Commentaires signalés</h3>
                </div>

                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-sm\">
                        <thead>
                        <tr class=\"text-white bg-danger\">
                            <th class=\"width20\">Pseudo</th>
                            <th>Commentaires</th>
                            <th class=\"width10\">Voir</th>
                            <th class=\"width10\">Garder</th>
                            <th class=\"width10\">Supp</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 165
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["commentreport"]);
        foreach ($context['_seq'] as $context["_key"] => $context["commentreport"]) {
            // line 166
            echo "
                            <tr>
                                <td>";
            // line 168
            echo $this->getAttribute($context["commentreport"], "pseudo", []);
            echo "</td>
                                <td>";
            // line 169
            echo twig_escape_filter($this->env, twig_truncate_filter($this->env, $this->getAttribute($context["commentreport"], "comment", []), 100), "html", null, true);
            echo "</td>
                                <td>
                                    <a href=\"index.php?p=comment_Office\">
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-info font-weight-bold \"
                                                name=\"commentLire\"
                                                value=\"";
            // line 175
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Voir\">
                                            <i data-feather=\"eye\"></i>
                                        </button>
                                    </a>
                                </td>
                                <form method=\"post\">
                                    <td>
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-success font-weight-bold \"
                                                name=\"classify\"
                                                value=\"";
            // line 186
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Garder\">
                                            <i data-feather=\"check\"></i>
                                        </button>
                                    </td>
                                    <td>
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                name=\"delete\"
                                                value=\"";
            // line 195
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Supprimer\">
                                            <i data-feather=\"delete\"></i>
                                        </button>
                                    </td>
                                </form>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['commentreport'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 203
        echo "                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

";
    }

    public function getTemplateName()
    {
        return "Admin/dashboard.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  316 => 203,  302 => 195,  290 => 186,  276 => 175,  267 => 169,  263 => 168,  259 => 166,  255 => 165,  229 => 141,  214 => 132,  205 => 126,  201 => 125,  197 => 123,  193 => 122,  167 => 98,  152 => 89,  145 => 85,  135 => 78,  126 => 72,  122 => 71,  118 => 69,  114 => 68,  89 => 45,  75 => 37,  66 => 31,  62 => 30,  59 => 29,  55 => 28,  31 => 6,  28 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}



{% block textarea %}

    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Bureau</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-lg-6 col-md-12  \">
            <div class=\"row padding\">
                <div class=\"col-12 shadow-lg p-2 mb-3 \">
                    <h3>Vos courriers</h3>
                </div>
                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-sm\">
                        <thead>
                        <tr class=\"text-white bg-success\">
                            <th class=\"width20\">Nom</th>
                            <th>Courriel</th>
                            <th class=\"width10\">Lire</th>
                        </tr>
                        </thead>
                        <tbody>
                        {% for mail in mail %}
                            <tr>
                                <td>{{ mail.name|raw }}</td>
                                <td>{{ mail.title|raw|truncate(50) }}</td>
                                <td>
                                    <a href=\"index.php?p=mail_Office\">
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-info font-weight-bold \"
                                                name=\"MailLire\"
                                                value=\"{{ commentreport.id }}\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Voir\">
                                            <i data-feather=\"eye\"></i>
                                        </button>
                                    </a>
                                </td>
                            </tr>
                        {% endfor %}
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        <div class=\"col-lg-6 col-md-12\">
            <div class=\"row padding\">
                <div class=\"col-12 shadow-lg p-2 mb-3 \">
                    <h3>Vos Publications en cours de rédaction</h3>
                </div>

                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-sm\">
                        <thead>
                        <tr class=\"text-white bg-info\">
                            <th>Titre</th>
                            <th>Date</th>
                            <th class=\"width10\">Voir</th>
                            <th class=\"width10\">Modif</th>
                        </tr>
                        </thead>
                        <tbody>
                        {% for book in chapitres %}

                            <tr>
                                <td>{{ book.title|raw }}</td>
                                <td>{{ book.date|date_modify ( \"+1 day\" )| date ( \"m/d/Y\"  ) }}</td>
                                <td>
                                    <a href=\"index.php?p=publication_Office\">
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-info font-weight-bold \"
                                                name=\"postLire\"
                                                value=\"{{ commentreport.id }}\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Voir\">
                                            <i data-feather=\"eye\"></i>
                                        </button>
                                    </a>
                                </td>
                                <td>
                                    <a href=\"index.php?p=posts_admin&id={{ book.id }}\">
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                                name=\"postModify\"
                                                value=\"{{ commentreport.id }}\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Modifier\">
                                            <i data-feather=\"edit-2\"></i>
                                        </button>
                                    </a>
                                </td>
                            </tr>

                        {% endfor %}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <br/>
    <div class=\"row\">
        <div class=\"col-lg-6 col-md-12 \">
            <div class=\"row padding\">
                <div class=\"col-12 shadow-lg p-2 mb-3 \">
                    <h3>Les derniers commentaires</h3>
                </div>

                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-sm\">
                        <thead>
                        <tr class=\"text-white bg-warning \">
                            <th class=\"width20\">Pseudo</th>
                            <th>Commentaires</th>
                            <th class=\"width10\">Lire</th>
                        </tr>
                        </thead>
                        <tbody>
                        {% for comment in comment %}

                            <tr>
                                <td>{{ comment.pseudo|raw }}</td>
                                <td>{{ comment.comment| raw|truncate(100) }}</td>
                                <td>
                                    <a href=\"index.php?p=comment_Office\" >
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-info font-weight-bold \"
                                                name=\"commentLire\"
                                                value=\"{{ commentreport.id }}\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"voir\">
                                            <i data-feather=\"eye\"></i>
                                        </button>
                                    </a>
                                </td>
                            </tr>

                        {% endfor %}

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class=\"col-lg-6 col-md-12\">
            <div class=\"row padding\">
                <div class=\"col-12 shadow-lg p-2 mb-3 \">
                    <h3>Commentaires signalés</h3>
                </div>

                <div class=\"table-responsive\">
                    <table class=\"table table-striped table-sm\">
                        <thead>
                        <tr class=\"text-white bg-danger\">
                            <th class=\"width20\">Pseudo</th>
                            <th>Commentaires</th>
                            <th class=\"width10\">Voir</th>
                            <th class=\"width10\">Garder</th>
                            <th class=\"width10\">Supp</th>
                        </tr>
                        </thead>
                        <tbody>
                        {% for commentreport in commentreport %}

                            <tr>
                                <td>{{ commentreport.pseudo|raw}}</td>
                                <td>{{ commentreport.comment| raw|truncate(100) }}</td>
                                <td>
                                    <a href=\"index.php?p=comment_Office\">
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-info font-weight-bold \"
                                                name=\"commentLire\"
                                                value=\"{{ commentreport.id }}\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Voir\">
                                            <i data-feather=\"eye\"></i>
                                        </button>
                                    </a>
                                </td>
                                <form method=\"post\">
                                    <td>
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-bg btn-success font-weight-bold \"
                                                name=\"classify\"
                                                value=\"{{ commentreport.id }}\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Garder\">
                                            <i data-feather=\"check\"></i>
                                        </button>
                                    </td>
                                    <td>
                                        <button type=\"submit\"
                                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                name=\"delete\"
                                                value=\"{{ commentreport.id }}\" data-toggle=\"tooltip\"
                                                data-placement=\"top\" title=\"Supprimer\">
                                            <i data-feather=\"delete\"></i>
                                        </button>
                                    </td>
                                </form>
                            </tr>
                        {% endfor %}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

{% endblock %}




", "Admin/dashboard.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Admin\\dashboard.html.twig");
    }
}
