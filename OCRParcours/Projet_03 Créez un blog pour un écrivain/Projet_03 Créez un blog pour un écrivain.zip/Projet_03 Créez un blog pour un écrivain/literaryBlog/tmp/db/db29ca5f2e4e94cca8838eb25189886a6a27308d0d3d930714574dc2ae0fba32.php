<?php

/* Posts/showShowing.html.twig */
class __TwigTemplate_95a938acc4def09acc60286de0d0b9afdfbe26184e7181886547340553928ee8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/GenericLayout/main.html.twig", "Posts/showShowing.html.twig", 1);
        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/GenericLayout/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "


        <div class=\"shadow-lg p-5 mb-5 bg-gradient-warning rounded headingheight\">

            <h1>Billet simple pour l'Alaska</h1>
            <br/>
        </div>
        <div class=\"paddingtext\">
            <img class=\"icoImg\" src=\"img/ico.png\" />
            <h2>";
        // line 14
        echo $this->getAttribute(($context["showing"] ?? null), "title", []);
        echo "</h2>
        </div>
        <div class=\"paddingtext\">
            <p>";
        // line 17
        echo $this->getAttribute(($context["showing"] ?? null), "text", []);
        echo "</p>
        </div>


";
    }

    public function getTemplateName()
    {
        return "Posts/showShowing.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 17,  43 => 14,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Layout/GenericLayout/main.html.twig'  %}

{% block content %}



        <div class=\"shadow-lg p-5 mb-5 bg-gradient-warning rounded headingheight\">

            <h1>Billet simple pour l'Alaska</h1>
            <br/>
        </div>
        <div class=\"paddingtext\">
            <img class=\"icoImg\" src=\"img/ico.png\" />
            <h2>{{ showing.title|raw }}</h2>
        </div>
        <div class=\"paddingtext\">
            <p>{{ showing.text|raw }}</p>
        </div>


{% endblock %}", "Posts/showShowing.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Posts\\showShowing.html.twig");
    }
}
