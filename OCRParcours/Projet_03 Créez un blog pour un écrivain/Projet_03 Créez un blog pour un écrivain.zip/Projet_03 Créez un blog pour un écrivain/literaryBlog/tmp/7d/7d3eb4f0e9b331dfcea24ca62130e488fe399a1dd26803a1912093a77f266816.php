<?php

/* Posts/home.html.twig */
class __TwigTemplate_3bb1a48faeca63fd544130398faa087a106a25078e9d1c0bf0c3b8d379320f21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layouthome.html.twig", "Posts/home.html.twig", 1);
        $this->blocks = [
            'introText' => [$this, 'block_introText'],
            'heading' => [$this, 'block_heading'],
            'content' => [$this, 'block_content'],
            'comment' => [$this, 'block_comment'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layouthome.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_introText($context, array $blocks = [])
    {
        // line 5
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["texthome"]);
        foreach ($context['_seq'] as $context["_key"] => $context["texthome"]) {
            // line 6
            echo "        <div id=\"introText\">
            <h1 class=\"paddingRL\">";
            // line 7
            echo $this->getAttribute($context["texthome"], "title", []);
            echo "</h1>
            <p class=\"paddingtext\">";
            // line 8
            echo $this->getAttribute($context["texthome"], "text", []);
            echo "</p>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['texthome'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    // line 13
    public function block_heading($context, array $blocks = [])
    {
        // line 14
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["headings"]);
        foreach ($context['_seq'] as $context["_key"] => $context["headings"]) {
            // line 15
            echo "        <div class=\"col-md-4 \">
            <div class=\"shadow-lg p-3 mb-5 bg-gradient-warning rounded headingheight\">
                <h2>";
            // line 17
            echo $this->getAttribute($context["headings"], "title", []);
            echo "</h2>
                <p class=\"paddingtext\">";
            // line 18
            echo twig_escape_filter($this->env, twig_truncate_filter($this->env, strip_tags($this->getAttribute($context["headings"], "text", [])), 150), "html", null, true);
            echo "<p/>
                <p>
                <h3 class=\"paddingRL\">
                    <a class=\"greenLink\"
                       href=\"index.php?p=heading_show&id=";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["headings"], "id", []), "html", null, true);
            echo "\">
                        En savoir plus...
                    </a>
                </h3>
                </p>
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['headings'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    // line 32
    public function block_content($context, array $blocks = [])
    {
        // line 33
        echo "    <h1 class=\"paddingRL\">Les derniers chapitres</h1>
    ";
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["chapitres"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 35
            echo "        <div class=\"paper padding paperPadding\">
            <h2>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "title", []), "html", null, true);
            echo "</h2>
            <p class=\"text-right\"> ";
            // line 37
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["book"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</p>
            <p class=\"paddingtext\">";
            // line 38
            echo twig_escape_filter($this->env, twig_truncate_filter($this->env, strip_tags($this->getAttribute($context["book"], "text", [])), 300), "html", null, true);
            echo "</p>
            <h3 class=\"paddingRL text-right\">
                <a class=\"greenLink\"
                   href=\"index.php?p=chapter_show&id=";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", []), "html", null, true);
            echo "\">
                    La suite...
                </a>
            </h3>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    // line 49
    public function block_comment($context, array $blocks = [])
    {
        // line 50
        echo "    <div class=\"row\">
        <div class=\"col col-12\">
    <h1 class=\"text-center\">Toujours en vente</h1>
    <div class=\"shadow-lg p-3 mb-5 bg-gradient-info rounded\">
        <div class=\"kiosque\">
            <p>
                <a id=\"livrePortrait\"><img src=\"img/EditionLibreAuteur.jpg\"/></a>
                <a id=\"livrePaysage\" ><img src=\"img/EditionLibreAuteurB.jpg\"/></a>
            </p>
            <br/>
            <a class=\"greenLink\" href=\"#\">Commander le livre</a>
        </div>
    </div>
        </div>
        <div class=\"col col-xl-12 col-lg-6 col-md-6 col-sm-12 col-12\">
    <h2 class=\"paddingRL\">Info sur le climat</h2>
    <div class=\"shadow-lg p-3 mb-5 bg-gradient-info rounded \">
        <div class=\"paddingtext giec text-center\">
            <p><a href=\"https://www.sauvonsleclimat.org/fr/\"><img src=\"img/LogoGiec.png\"/></a></p>
        </div>
    </div>
        </div>
        <div class=\"col col-xl-12 col-lg-6 col-md-6 col-sm-12 col-12\">
    <h2 class=\"paddingRL\">Lire, voir, réagir, ...</h2>
    <div class=\"shadow-lg p-3 mb-5 bg-gradient-info rounded network\">
        <div class=\"paddingtext text-center\">
            <p><a><img src=\"img/faceBook.png\"/></a>
                <a><img src=\"img/twitter.png\"/></a>
                <a><img src=\"img/youtube.png\"/></a>
                <a><img src=\"img/In.png\"/></a>
            </p>
        </div>
    </div>
        </div>
    </div>


";
    }

    public function getTemplateName()
    {
        return "Posts/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 50,  137 => 49,  123 => 41,  117 => 38,  113 => 37,  109 => 36,  106 => 35,  102 => 34,  99 => 33,  96 => 32,  80 => 22,  73 => 18,  69 => 17,  65 => 15,  60 => 14,  57 => 13,  46 => 8,  42 => 7,  39 => 6,  34 => 5,  31 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Layout/layouthome.html.twig' %}


{% block introText %}
    {% for texthome in texthome %}
        <div id=\"introText\">
            <h1 class=\"paddingRL\">{{ texthome.title|raw  }}</h1>
            <p class=\"paddingtext\">{{ texthome.text |raw }}</p>
        </div>
    {% endfor %}
{% endblock %}

{% block heading %}
    {% for headings in headings %}
        <div class=\"col-md-4 \">
            <div class=\"shadow-lg p-3 mb-5 bg-gradient-warning rounded headingheight\">
                <h2>{{ headings.title|raw }}</h2>
                <p class=\"paddingtext\">{{ headings.text |striptags|raw |truncate(150) }}<p/>
                <p>
                <h3 class=\"paddingRL\">
                    <a class=\"greenLink\"
                       href=\"index.php?p=heading_show&id={{ headings.id }}\">
                        En savoir plus...
                    </a>
                </h3>
                </p>
            </div>
        </div>
    {% endfor %}
{% endblock %}

{% block content %}
    <h1 class=\"paddingRL\">Les derniers chapitres</h1>
    {% for book in chapitres %}
        <div class=\"paper padding paperPadding\">
            <h2>{{ book.title }}</h2>
            <p class=\"text-right\"> {{ book.date| date_modify ( \"+1 day\" )| date ( \"m/d/Y\" ) }}</p>
            <p class=\"paddingtext\">{{ book.text|striptags|raw | truncate(300) }}</p>
            <h3 class=\"paddingRL text-right\">
                <a class=\"greenLink\"
                   href=\"index.php?p=chapter_show&id={{ book.id }}\">
                    La suite...
                </a>
            </h3>
        </div>
    {% endfor %}
{% endblock %}

{% block comment %}
    <div class=\"row\">
        <div class=\"col col-12\">
    <h1 class=\"text-center\">Toujours en vente</h1>
    <div class=\"shadow-lg p-3 mb-5 bg-gradient-info rounded\">
        <div class=\"kiosque\">
            <p>
                <a id=\"livrePortrait\"><img src=\"img/EditionLibreAuteur.jpg\"/></a>
                <a id=\"livrePaysage\" ><img src=\"img/EditionLibreAuteurB.jpg\"/></a>
            </p>
            <br/>
            <a class=\"greenLink\" href=\"#\">Commander le livre</a>
        </div>
    </div>
        </div>
        <div class=\"col col-xl-12 col-lg-6 col-md-6 col-sm-12 col-12\">
    <h2 class=\"paddingRL\">Info sur le climat</h2>
    <div class=\"shadow-lg p-3 mb-5 bg-gradient-info rounded \">
        <div class=\"paddingtext giec text-center\">
            <p><a href=\"https://www.sauvonsleclimat.org/fr/\"><img src=\"img/LogoGiec.png\"/></a></p>
        </div>
    </div>
        </div>
        <div class=\"col col-xl-12 col-lg-6 col-md-6 col-sm-12 col-12\">
    <h2 class=\"paddingRL\">Lire, voir, réagir, ...</h2>
    <div class=\"shadow-lg p-3 mb-5 bg-gradient-info rounded network\">
        <div class=\"paddingtext text-center\">
            <p><a><img src=\"img/faceBook.png\"/></a>
                <a><img src=\"img/twitter.png\"/></a>
                <a><img src=\"img/youtube.png\"/></a>
                <a><img src=\"img/In.png\"/></a>
            </p>
        </div>
    </div>
        </div>
    </div>


{% endblock %}", "Posts/home.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Posts\\home.html.twig");
    }
}
