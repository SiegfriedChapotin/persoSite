<?php

/* Admin/Modification/textRgpdModif.html.twig */
class __TwigTemplate_5c86e7dce03a766a2882033355064014bfdd016fa0c5ede312e82bba6345a6b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/Modification/textRgpdModif.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_textarea($context, array $blocks = [])
    {
        // line 6
        echo "
    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Page d'accueil</h1>
    </div>

    ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["rgpd_admin"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["rgpd"]) {
            // line 13
            echo "        <form method=\"post\">
            <div class=\" row justify-content-center font-weight-bold \">
                <div class=\"col-10\">
                    <label for=\"TitleDashboard\">Titre</label>
                    <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" value=\"";
            // line 17
            echo twig_escape_filter($this->env, strip_tags($this->getAttribute($context["rgpd"], "title", [])), "html", null, true);
            echo "\"
                           required/>
                </div>
            </div>
            <div class=\" row justify-content-center font-weight-bold \">
                <div class=\"col-11\">
                    <label for=\"TextDashboard\"> Texte </label>
                    <textarea class=\"form-control textarea\" id=\"adminTextarea\" rows=\"20\"
                              name=\"TextDashboard\">";
            // line 25
            echo $this->getAttribute($context["rgpd"], "text", []);
            echo "</textarea>
                </div>
            </div>
            <div class=\"row justify-content-center \">
                <div class=\"col-10\">
                    <div class=\"paddingtext row  \">
                        <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                            <a href=\"index.php?p=posts_admin&id=";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["rgpd"], "id", []), "html", null, true);
            echo "\">
                                <button type=\"submit\"
                                        class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                        name=\"postModify\"
                                        value=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["rgpd"], "id", []), "html", null, true);
            echo "\">
                                    <a class=\" paddingRL\">Modifier</a>
                                    <i data-feather=\"edit-2\"></i>
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rgpd'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "
";
    }

    public function getTemplateName()
    {
        return "Admin/Modification/textRgpdModif.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 47,  77 => 36,  70 => 32,  60 => 25,  49 => 17,  43 => 13,  39 => 12,  31 => 6,  28 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}



{% block textarea %}

    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Page d'accueil</h1>
    </div>

    {% for rgpd in rgpd_admin %}
        <form method=\"post\">
            <div class=\" row justify-content-center font-weight-bold \">
                <div class=\"col-10\">
                    <label for=\"TitleDashboard\">Titre</label>
                    <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" value=\"{{ rgpd.title|striptags }}\"
                           required/>
                </div>
            </div>
            <div class=\" row justify-content-center font-weight-bold \">
                <div class=\"col-11\">
                    <label for=\"TextDashboard\"> Texte </label>
                    <textarea class=\"form-control textarea\" id=\"adminTextarea\" rows=\"20\"
                              name=\"TextDashboard\">{{ rgpd.text|raw }}</textarea>
                </div>
            </div>
            <div class=\"row justify-content-center \">
                <div class=\"col-10\">
                    <div class=\"paddingtext row  \">
                        <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                            <a href=\"index.php?p=posts_admin&id={{ rgpd.id }}\">
                                <button type=\"submit\"
                                        class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                        name=\"postModify\"
                                        value=\"{{ rgpd.id }}\">
                                    <a class=\" paddingRL\">Modifier</a>
                                    <i data-feather=\"edit-2\"></i>
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    {% endfor %}

{% endblock %}", "Admin/Modification/textRgpdModif.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Admin\\Modification\\textRgpdModif.html.twig");
    }
}
