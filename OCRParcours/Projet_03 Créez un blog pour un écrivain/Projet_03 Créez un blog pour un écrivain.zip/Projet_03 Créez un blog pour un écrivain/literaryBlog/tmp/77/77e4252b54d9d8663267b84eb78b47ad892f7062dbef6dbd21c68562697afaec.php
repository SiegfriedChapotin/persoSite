<?php

/* Admin/Modification/textShowingModif.html.twig */
class __TwigTemplate_07019b468659569385169b90468d929d91617ae0395e691b3f8514968c6edd7b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/Modification/textShowingModif.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_textarea($context, array $blocks = [])
    {
        // line 4
        echo "
    ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["showing_admin"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["showing"]) {
            // line 6
            echo "        <br/>
        <div class=\"col-12 shadow-lg p-4 mb-5  \">
            <h1>Profil</h1>
        </div>

        <form method=\"post\">
            <div class=\" row justify-content-between font-weight-bold \">
                <div class=\"col-4\">

                </div>
                <div class=\"col-3\">
                    <div class=\"form-group\">
                        <div class=\"row\">
                            <div class=\"col-6 form-check form-check-inline\">
                                <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status0\" value=\"0\"
                                        ";
            // line 21
            echo ((($this->getAttribute($context["showing"], "classify", []) == 0)) ? ("checked") : (""));
            echo " >
                                <label class=\"form-check-label\" for=\"is_status0\">Brouillon
                                </label>
                            </div>
                            <div class=\"col-6 form-check form-check-inline  \">
                                <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status1\"
                                       value=\"1\" ";
            // line 27
            echo ((($this->getAttribute($context["showing"], "classify", []) == 1)) ? ("checked") : (""));
            echo " >
                                <label class=\"form-check-label\" for=\"is_status1\">Editer
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\" row justify-content-center font-weight-bold \">
                <div class=\"col-10\">
                    <label for=\"TitleDashboard\" class=\"paddingtext font-weight-bold\">Titre</label>
                    <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" value=\"";
            // line 38
            echo twig_escape_filter($this->env, strip_tags($this->getAttribute($context["showing"], "title", [])), "html", null, true);
            echo "\"
                           required>
                </div>
            </div>

            <div class=\" row justify-content-center font-weight-bold \">
                <div class=\"col-11\">
                    <label for=\"TextDashboard\" class=\"paddingtext font-weight-bold\">Texte</label>
                    <textarea class=\"form-control adminTextarea\" id=\"adminTextarea\" rows=\"20\"
                              name=\"TextDashboard\">";
            // line 47
            echo $this->getAttribute($context["showing"], "text", []);
            echo "</textarea>
                </div>
            </div>
            <div class=\"row justify-content-center \">
                <div class=\"col-10\">
                    <div class=\"paddingtext row \">
                        <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                            <a href=\"index.php?p=posts_admin&id=";
            // line 54
            echo twig_escape_filter($this->env, $this->getAttribute($context["showing"], "id", []), "html", null, true);
            echo "\">
                                <button type=\"submit\"
                                        class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                        name=\"postModify\"
                                        value=\"";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["showing"], "id", []), "html", null, true);
            echo "\">
                                    <a class=\" paddingRL\">Modifier</a>
                                    <i data-feather=\"edit-2\"></i>
                                </button>
                            </a>

                        </div>
                        <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                            <button type=\"submit\"
                                    class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                    name=\"delete\"
                                    value=\"";
            // line 69
            echo twig_escape_filter($this->env, $this->getAttribute($context["showing"], "id", []), "html", null, true);
            echo "\">
                                <a class=\" paddingRL\"> Supprimer</a>
                                <i data-feather=\"delete\"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['showing'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 80
        echo "    <wbr/>
";
    }

    public function getTemplateName()
    {
        return "Admin/Modification/textShowingModif.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 80,  121 => 69,  107 => 58,  100 => 54,  90 => 47,  78 => 38,  64 => 27,  55 => 21,  38 => 6,  34 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"Layout/layoutdashboard.html.twig\" %}

{% block textarea %}

    {% for showing in showing_admin %}
        <br/>
        <div class=\"col-12 shadow-lg p-4 mb-5  \">
            <h1>Profil</h1>
        </div>

        <form method=\"post\">
            <div class=\" row justify-content-between font-weight-bold \">
                <div class=\"col-4\">

                </div>
                <div class=\"col-3\">
                    <div class=\"form-group\">
                        <div class=\"row\">
                            <div class=\"col-6 form-check form-check-inline\">
                                <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status0\" value=\"0\"
                                        {{ (showing.classify == 0)? 'checked':'' }} >
                                <label class=\"form-check-label\" for=\"is_status0\">Brouillon
                                </label>
                            </div>
                            <div class=\"col-6 form-check form-check-inline  \">
                                <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status1\"
                                       value=\"1\" {{ (showing.classify == 1)?'checked':'' }} >
                                <label class=\"form-check-label\" for=\"is_status1\">Editer
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\" row justify-content-center font-weight-bold \">
                <div class=\"col-10\">
                    <label for=\"TitleDashboard\" class=\"paddingtext font-weight-bold\">Titre</label>
                    <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" value=\"{{ showing.title|striptags }}\"
                           required>
                </div>
            </div>

            <div class=\" row justify-content-center font-weight-bold \">
                <div class=\"col-11\">
                    <label for=\"TextDashboard\" class=\"paddingtext font-weight-bold\">Texte</label>
                    <textarea class=\"form-control adminTextarea\" id=\"adminTextarea\" rows=\"20\"
                              name=\"TextDashboard\">{{ showing.text|raw }}</textarea>
                </div>
            </div>
            <div class=\"row justify-content-center \">
                <div class=\"col-10\">
                    <div class=\"paddingtext row \">
                        <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                            <a href=\"index.php?p=posts_admin&id={{ showing.id }}\">
                                <button type=\"submit\"
                                        class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                        name=\"postModify\"
                                        value=\"{{ showing.id }}\">
                                    <a class=\" paddingRL\">Modifier</a>
                                    <i data-feather=\"edit-2\"></i>
                                </button>
                            </a>

                        </div>
                        <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                            <button type=\"submit\"
                                    class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                    name=\"delete\"
                                    value=\"{{ showing.id }}\">
                                <a class=\" paddingRL\"> Supprimer</a>
                                <i data-feather=\"delete\"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

    {% endfor %}
    <wbr/>
{% endblock %}", "Admin/Modification/textShowingModif.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Admin\\Modification\\textShowingModif.html.twig");
    }
}
