<?php

/* Posts/book.html.twig */
class __TwigTemplate_a4500b000283435a1ab15714b3bc2577dda96f61246a8dc11ec199a491b46f6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/GenericLayout/main.html.twig", "Posts/book.html.twig", 1);
        $this->blocks = [
            'writecomment' => [$this, 'block_writecomment'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/GenericLayout/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_writecomment($context, array $blocks = [])
    {
        // line 5
        echo "
    <div class=\"shadow-lg p-3 mb-5 bg-gradient-warning rounded headingheight\">
        <a><img class=\"img-fluid\" alt=\"Responsive image\" src=\"img/billetsimplealaskaRS.png\"></a>
    </div>

    <div id=\"accordion\">
        ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["chapitreall"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 12
            echo "
            <div class=\"card book\">
                <div class=\"card-header\" id=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", []), "html", null, true);
            echo "\">
                    <h5 class=\"mb-0\">
                        <button class=\"btn btn-link greenLink collapsed\" data-toggle=\"collapse\"
                                data-target=\"#collapse";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                aria-controls=\"collapse";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", []), "html", null, true);
            echo "\">
                            <h5 class=\"hiddenEle\">Chapitre : ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "chapter", []), "html", null, true);
            echo " </h5>
                            <h5 class=\"visibleEle\">";
            // line 20
            echo $this->getAttribute($context["book"], "title", []);
            echo "</h5>
                        </button>
                    </h5>
                </div>
                <div id=\"collapse";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", []), "html", null, true);
            echo "\" class=\"collapse paper\" aria-labelledby=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", []), "html", null, true);
            echo "\"
                     data-parent=\"#accordion\">
                    <div class=\"card-body\">
                        ";
            // line 27
            echo $this->getAttribute($context["book"], "text", []);
            echo "
                    </div>
                    <div class=\"padding text-center\">
                        <a href=\"index.php?p=chapter_show&id=";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["book"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-light btn-lg greenLink\"
                           role=\"button\">
                            <span class=\"hiddenEle\">Commentaires</span>
                            <span class=\"visibleEle\">Je vous en prie, dites moi ce que vous en pensez.</span>
                        </a>
                    </div>
                </div>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "Posts/book.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  101 => 39,  86 => 30,  80 => 27,  72 => 24,  65 => 20,  61 => 19,  57 => 18,  53 => 17,  47 => 14,  43 => 12,  39 => 11,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Layout/GenericLayout/main.html.twig' %}


{% block writecomment %}

    <div class=\"shadow-lg p-3 mb-5 bg-gradient-warning rounded headingheight\">
        <a><img class=\"img-fluid\" alt=\"Responsive image\" src=\"img/billetsimplealaskaRS.png\"></a>
    </div>

    <div id=\"accordion\">
        {% for book in chapitreall %}

            <div class=\"card book\">
                <div class=\"card-header\" id=\"{{ book.id }}\">
                    <h5 class=\"mb-0\">
                        <button class=\"btn btn-link greenLink collapsed\" data-toggle=\"collapse\"
                                data-target=\"#collapse{{ book.id }}\" aria-expanded=\"true\"
                                aria-controls=\"collapse{{ book.id }}\">
                            <h5 class=\"hiddenEle\">Chapitre : {{ book.chapter }} </h5>
                            <h5 class=\"visibleEle\">{{ book.title|raw }}</h5>
                        </button>
                    </h5>
                </div>
                <div id=\"collapse{{ book.id }}\" class=\"collapse paper\" aria-labelledby=\"{{ book.id }}\"
                     data-parent=\"#accordion\">
                    <div class=\"card-body\">
                        {{ book.text|raw }}
                    </div>
                    <div class=\"padding text-center\">
                        <a href=\"index.php?p=chapter_show&id={{ book.id }}\" class=\"btn btn-light btn-lg greenLink\"
                           role=\"button\">
                            <span class=\"hiddenEle\">Commentaires</span>
                            <span class=\"visibleEle\">Je vous en prie, dites moi ce que vous en pensez.</span>
                        </a>
                    </div>
                </div>
            </div>
        {% endfor %}
    </div>
{% endblock %}

", "Posts/book.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Posts\\book.html.twig");
    }
}
