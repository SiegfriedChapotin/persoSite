<?php

/* Layout/layouthome.html.twig */
class __TwigTemplate_5c75dfda29a4aea7a5ce532ec6b4d10a8d84110fdf39abfde028069f56337159 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'introText' => [$this, 'block_introText'],
            'heading' => [$this, 'block_heading'],
            'content' => [$this, 'block_content'],
            'comment' => [$this, 'block_comment'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $this->loadTemplate("Layout/GenericLayout/header.html.twig", "Layout/layouthome.html.twig", 1)->display($context);
        // line 2
        echo "
<main role=\"main\">

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class=\"jumbotron\">
        <div class=\"container\">
            ";
        // line 8
        $this->displayBlock('introText', $context, $blocks);
        // line 9
        echo "        </div>
    </div>

    <div class=\"container-fluid\">
        <!-- Example row of columns -->
        <div class=\"row \">

            ";
        // line 16
        $this->displayBlock('heading', $context, $blocks);
        // line 17
        echo "        </div>
        <hr>
    </div>

    <div class=\"container-fluid\">
        <!-- Example row of columns -->
        <div class=\"row\">
            <div class=\"col col-xl-9 col-lg-12 col-md-12 col-sm-12 col-12\">
                ";
        // line 25
        $this->displayBlock('content', $context, $blocks);
        // line 26
        echo "            </div>
            <div class=\"col col-xl-3 col-lg-12 col-md-12 col-sm-12 col-12\">
                ";
        // line 28
        $this->displayBlock('comment', $context, $blocks);
        // line 29
        echo "            </div>
        </div>
    </div>

    <!-- /container -->

</main>

";
        // line 37
        $this->loadTemplate("Layout/GenericLayout/footer.html.twig", "Layout/layouthome.html.twig", 37)->display($context);
    }

    // line 8
    public function block_introText($context, array $blocks = [])
    {
    }

    // line 16
    public function block_heading($context, array $blocks = [])
    {
    }

    // line 25
    public function block_content($context, array $blocks = [])
    {
    }

    // line 28
    public function block_comment($context, array $blocks = [])
    {
    }

    public function getTemplateName()
    {
        return "Layout/layouthome.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 28,  88 => 25,  83 => 16,  78 => 8,  74 => 37,  64 => 29,  62 => 28,  58 => 26,  56 => 25,  46 => 17,  44 => 16,  35 => 9,  33 => 8,  25 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include  \"Layout/GenericLayout/header.html.twig\" %}

<main role=\"main\">

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class=\"jumbotron\">
        <div class=\"container\">
            {% block introText %}{% endblock %}
        </div>
    </div>

    <div class=\"container-fluid\">
        <!-- Example row of columns -->
        <div class=\"row \">

            {% block heading %}{% endblock %}
        </div>
        <hr>
    </div>

    <div class=\"container-fluid\">
        <!-- Example row of columns -->
        <div class=\"row\">
            <div class=\"col col-xl-9 col-lg-12 col-md-12 col-sm-12 col-12\">
                {% block content %}{% endblock %}
            </div>
            <div class=\"col col-xl-3 col-lg-12 col-md-12 col-sm-12 col-12\">
                {% block comment %}{% endblock %}
            </div>
        </div>
    </div>

    <!-- /container -->

</main>

{% include  \"Layout/GenericLayout/footer.html.twig\" %}", "Layout/layouthome.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Layout\\layouthome.html.twig");
    }
}
