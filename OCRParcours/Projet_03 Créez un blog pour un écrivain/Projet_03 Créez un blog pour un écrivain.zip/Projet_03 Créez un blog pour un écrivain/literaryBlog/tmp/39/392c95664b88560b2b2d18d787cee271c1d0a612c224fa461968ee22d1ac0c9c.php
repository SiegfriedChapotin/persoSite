<?php

/* Layout/GenericLayout/footer.html.twig */
class __TwigTemplate_eb9c2aeea97831b625783abb8272ba9f72f56c9f5bd4bd9829373990318846e0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<footer class=\"container-fluid\">
    <hr/>
    <div class=\"row\">
        <div class=\"col col-2\">
            <a id=\"connection\" href=\"index.php?p=Admin\">
                <span data-feather=\"feather\"></span>
            </a>
        </div>
        <div class=\"col col-xl-8 col-lg-7 col-md-6 col-sm-5 col-2\">
        </div>

        <div class=\"col col-xl-2 col-lg-3 col-md-4 col-sm-5 col-8 text-center\">
            <a>&copy; Jean Forteroche 2018</a>
            <br/>

            <a href=\"index.php?p=rgpd_show\">
                <span class=\"badge badge-dark \"> Mentions légales RGPD</span>
            </a>
        </div>
    </div>
</footer>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://code.jquery.com/jquery-3.3.1.slim.min.js\"
        integrity=\"sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo\"
        crossorigin=\"anonymous\"></script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js\"
        integrity=\"sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49\"
        crossorigin=\"anonymous\"></script>
<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js\"
        integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\"
        crossorigin=\"anonymous\"></script>
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
<!-- Icons -->
<script src=\"https://unpkg.com/feather-icons/dist/feather.min.js\"></script>
<script>
    feather.replace()
</script>

<script type=\"text/javascript\" src=\"../vendor/tinymce/tinymce/tinymce.js\"></script>
<!-- Just be careful that you give correct path to your tinymce.min.js file, above is the default example -->
<script type=\"text/javascript\" >
    tinymce.init({
        mode: \"exact\",
        selector: \"#adminTextarea\",
        element:\"#adminTextarea\",
        language: \"fr_FR\",
        entity_encoding: \"raw\",
        encoding: \"UTF-8\",

        plugins: 'print preview  paste searchreplace autolink directionality  visualblocks visualchars fullscreen image link media template table charmap hr pagebreak nonbreaking anchor insertdatetime advlist lists wordcount   imagetools textpattern',
        toolbar: 'formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat',
    });
</script>

</body>
</html>";
    }

    public function getTemplateName()
    {
        return "Layout/GenericLayout/footer.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<footer class=\"container-fluid\">
    <hr/>
    <div class=\"row\">
        <div class=\"col col-2\">
            <a id=\"connection\" href=\"index.php?p=Admin\">
                <span data-feather=\"feather\"></span>
            </a>
        </div>
        <div class=\"col col-xl-8 col-lg-7 col-md-6 col-sm-5 col-2\">
        </div>

        <div class=\"col col-xl-2 col-lg-3 col-md-4 col-sm-5 col-8 text-center\">
            <a>&copy; Jean Forteroche 2018</a>
            <br/>

            <a href=\"index.php?p=rgpd_show\">
                <span class=\"badge badge-dark \"> Mentions légales RGPD</span>
            </a>
        </div>
    </div>
</footer>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://code.jquery.com/jquery-3.3.1.slim.min.js\"
        integrity=\"sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo\"
        crossorigin=\"anonymous\"></script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js\"
        integrity=\"sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49\"
        crossorigin=\"anonymous\"></script>
<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js\"
        integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\"
        crossorigin=\"anonymous\"></script>
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
<!-- Icons -->
<script src=\"https://unpkg.com/feather-icons/dist/feather.min.js\"></script>
<script>
    feather.replace()
</script>

<script type=\"text/javascript\" src=\"../vendor/tinymce/tinymce/tinymce.js\"></script>
<!-- Just be careful that you give correct path to your tinymce.min.js file, above is the default example -->
<script type=\"text/javascript\" >
    tinymce.init({
        mode: \"exact\",
        selector: \"#adminTextarea\",
        element:\"#adminTextarea\",
        language: \"fr_FR\",
        entity_encoding: \"raw\",
        encoding: \"UTF-8\",

        plugins: 'print preview  paste searchreplace autolink directionality  visualblocks visualchars fullscreen image link media template table charmap hr pagebreak nonbreaking anchor insertdatetime advlist lists wordcount   imagetools textpattern',
        toolbar: 'formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat',
    });
</script>

</body>
</html>", "Layout/GenericLayout/footer.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Layout\\GenericLayout\\footer.html.twig");
    }
}
