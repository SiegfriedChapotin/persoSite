<?php

/* Posts/show.html.twig */
class __TwigTemplate_df16e3d51eb8a16ed779731229e4ed6ac05ddf90f2113037cf41365b6487c431 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/GenericLayout/main.html.twig", "Posts/show.html.twig", 1);
        $this->blocks = [
            'content' => [$this, 'block_content'],
            'comment' => [$this, 'block_comment'],
            'writecomment' => [$this, 'block_writecomment'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/GenericLayout/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_content($context, array $blocks = [])
    {
        // line 5
        echo "    <div class=\"shadow-lg p-5 mb-5 bg-gradient-warning rounded headingheight\">
        <h1>Billet simple pour l'Alaska</h1>
        <br/>
    </div>
    <div class=\"paper padding\">
        <h2>";
        // line 10
        echo $this->getAttribute(($context["chapitre"] ?? null), "title", []);
        echo "</h2>
        <p class=\"text-right\">";
        // line 11
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute(($context["chapitre"] ?? null), "date", []), "+1 day"), "m/d/Y"), "html", null, true);
        echo "</p>
        <p class=\"paddingtext\">";
        // line 12
        echo $this->getAttribute(($context["chapitre"] ?? null), "text", []);
        echo "</p>
    </div>
";
    }

    // line 16
    public function block_comment($context, array $blocks = [])
    {
        // line 17
        echo "    <br/>
    <hr/>
    <br/>
    <h2>Dites moi tout sur ce chapitre !</h2>
    <p><a href=\"#comment\" class=\"greenLink\">En 500 caractéres maximum</a></p>
    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["comments"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 23
            echo "        <form method=\"post\">

            <div class=\"shadow-lg p-3 mb-5 bg-gradient-info rounded text-white\">
                <div class=\"row\">
                    <div class=\"col-lg-10 col-sm-8 col-8\">
                        <h5 class=\"font-weight-bold\">";
            // line 28
            echo $this->getAttribute($context["comment"], "pseudo", []);
            echo "</h5>
                        <a>";
            // line 29
            echo $this->getAttribute($context["comment"], "comment", []);
            echo " </a> <br/>
                    </div>
                    <div class=\"col-lg-2 col-sm-4 col-4\">
                        <button type=\"submit\"
                                class=\"btn btn-card btn-bg btn-danger font-weight-bold \"
                                name=\"classify\"
                                value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["comment"], "id", []), "html", null, true);
            echo "\">
                            <a class=\"visibleEle paddingRL\">Signaler</a> <i data-feather=\"bell\"></i>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    // line 45
    public function block_writecomment($context, array $blocks = [])
    {
        // line 46
        echo "    <div class=\"accordion\" id=\"accordionExample\">
        <div class=\"card\">
            <div class=\"card-header\" id=\"comment\">

                <h3 class=\"mb-0 ";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", []), "cookies", []), "get", [0 => "authToken"], "method"), "html", null, true);
        echo "\">
                    <a class=\"btn btn-link greenLink  collapsed\" type=\"button\" data-toggle=\"collapse\"
                       data-target=\"#collapseTwo\" aria-expanded=\"false\" aria-controls=\"collapseTwo\">
                        Dites moi ce que vous en pensez.
                    </a>
                </h3>
            </div>
            <div id=\"collapseTwo\" class=\"collapse\" aria-labelledby=\"comment\" data-parent=\"#accordionExample\">
                <div class=\"card-body \">
                    <form method=\"post\" action=\"\" id=\"comment\">
                        <input type=\"hidden\" id=\"recaptcha\" name=\"recaptcha\">

                        <label for=\"pseudo\">Pseudo</label>
                        <input type=\"text\" class=\"form-control\" maxlength=\"30\" name=\"pseudo\" id=\"pseudo\"
                               placeholder=\"Pseudo\" required>

                        <label for=\"comment\">Votre commentaire </label>
                        <textarea class=\"form-control\" maxlength=\"500\" name=\"comment\" id=\"comment\" rows=\"10\"
                                  required></textarea>
                        <br/>
                        <input type=\"hidden\" name=\"csrf_token\" value=\"";
        // line 70
        echo twig_escape_filter($this->env, ($context["csrf_token"] ?? null), "html", null, true);
        echo "\"/>

                        <input class=\"btn btn-info\" type=\"submit\" name=\"Valider\" value=\"Valider\"/>
                        <input class=\"btn btn-secondary\" type=\"reset\" value=\"Effacer\"/>
                    </form>
                </div>
            </div>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "Posts/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 70,  114 => 50,  108 => 46,  105 => 45,  89 => 35,  80 => 29,  76 => 28,  69 => 23,  65 => 22,  58 => 17,  55 => 16,  48 => 12,  44 => 11,  40 => 10,  33 => 5,  30 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Layout/GenericLayout/main.html.twig' %}


{% block content %}
    <div class=\"shadow-lg p-5 mb-5 bg-gradient-warning rounded headingheight\">
        <h1>Billet simple pour l'Alaska</h1>
        <br/>
    </div>
    <div class=\"paper padding\">
        <h2>{{ chapitre.title|raw }}</h2>
        <p class=\"text-right\">{{ chapitre.date| date_modify ( \"+1 day\" )| date ( \"m/d/Y\" ) }}</p>
        <p class=\"paddingtext\">{{ chapitre.text|raw }}</p>
    </div>
{% endblock %}

{% block comment %}
    <br/>
    <hr/>
    <br/>
    <h2>Dites moi tout sur ce chapitre !</h2>
    <p><a href=\"#comment\" class=\"greenLink\">En 500 caractéres maximum</a></p>
    {% for comment in comments %}
        <form method=\"post\">

            <div class=\"shadow-lg p-3 mb-5 bg-gradient-info rounded text-white\">
                <div class=\"row\">
                    <div class=\"col-lg-10 col-sm-8 col-8\">
                        <h5 class=\"font-weight-bold\">{{ comment.pseudo|raw }}</h5>
                        <a>{{ comment.comment|raw }} </a> <br/>
                    </div>
                    <div class=\"col-lg-2 col-sm-4 col-4\">
                        <button type=\"submit\"
                                class=\"btn btn-card btn-bg btn-danger font-weight-bold \"
                                name=\"classify\"
                                value=\"{{ comment.id }}\">
                            <a class=\"visibleEle paddingRL\">Signaler</a> <i data-feather=\"bell\"></i>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    {% endfor %}
{% endblock %}

{% block writecomment %}
    <div class=\"accordion\" id=\"accordionExample\">
        <div class=\"card\">
            <div class=\"card-header\" id=\"comment\">

                <h3 class=\"mb-0 {{ app.request.cookies.get(\"authToken\") }}\">
                    <a class=\"btn btn-link greenLink  collapsed\" type=\"button\" data-toggle=\"collapse\"
                       data-target=\"#collapseTwo\" aria-expanded=\"false\" aria-controls=\"collapseTwo\">
                        Dites moi ce que vous en pensez.
                    </a>
                </h3>
            </div>
            <div id=\"collapseTwo\" class=\"collapse\" aria-labelledby=\"comment\" data-parent=\"#accordionExample\">
                <div class=\"card-body \">
                    <form method=\"post\" action=\"\" id=\"comment\">
                        <input type=\"hidden\" id=\"recaptcha\" name=\"recaptcha\">

                        <label for=\"pseudo\">Pseudo</label>
                        <input type=\"text\" class=\"form-control\" maxlength=\"30\" name=\"pseudo\" id=\"pseudo\"
                               placeholder=\"Pseudo\" required>

                        <label for=\"comment\">Votre commentaire </label>
                        <textarea class=\"form-control\" maxlength=\"500\" name=\"comment\" id=\"comment\" rows=\"10\"
                                  required></textarea>
                        <br/>
                        <input type=\"hidden\" name=\"csrf_token\" value=\"{{ csrf_token }}\"/>

                        <input class=\"btn btn-info\" type=\"submit\" name=\"Valider\" value=\"Valider\"/>
                        <input class=\"btn btn-secondary\" type=\"reset\" value=\"Effacer\"/>
                    </form>
                </div>
            </div>
        </div>
    </div>

{% endblock %}", "Posts/show.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Posts\\show.html.twig");
    }
}
