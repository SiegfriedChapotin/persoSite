<?php

/* Admin/Office/officeMail.html.twig */
class __TwigTemplate_24e21bcd489124f6251679f5fcf822d26a4972c325dd6b7f9080b9a22b8ce458 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/Office/officeMail.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_textarea($context, array $blocks = [])
    {
        // line 4
        echo "
    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Votre messagerie</h1>
    </div>

    <div class=\"col-12 shadow-lg p-2 mb-5 p-lg-5\">
        <nav>
            <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
                <a class=\"nav-item nav-link active\" id=\"nav-news-tab\" data-toggle=\"tab\" href=\"#nav-news\" role=\"tab\"
                   aria-controls=\"nav-news\" aria-selected=\"true\"><h3>Nouveaux messages</h3></a>
                <a class=\"nav-item nav-link\" id=\"nav-archives-tab\" data-toggle=\"tab\" href=\"#nav-archives\" role=\"tab\"
                   aria-controls=\"nav-archives\" aria-selected=\"false\"><h3>Archives</h3></a>
            </div>
        </nav>
        <div class=\"tab-content\" id=\"nav-tabContent\">
            <div class=\"tab-pane fade show active\" id=\"nav-news\" role=\"tabpanel\" aria-labelledby=\"nav-news-tab\">
                <div id=\"accordion\">
                    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["mailoffice"]);
        foreach ($context['_seq'] as $context["_key"] => $context["mailoffice"]) {
            // line 23
            echo "                        <div>
                            <div class=\"card-header\" id=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "id", []), "html", null, true);
            echo "\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-5 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 27
            echo $this->getAttribute($context["mailoffice"], "name", []);
            echo "</a>
                                    </div>
                                    <div class=\"col col-lg-8 paddingtext\">
                                        <a class=\"paddingRL visibleEleMD\"> ";
            // line 30
            echo $this->getAttribute($context["mailoffice"], "title", []);
            echo "</a>
                                    </div>
                                    <div class=\"col col-sm-5  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-success font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                                aria-controls=\"collapse";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "id", []), "html", null, true);
            echo "\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "id", []), "html", null, true);
            echo "\" class=\"collapse\" aria-labelledby=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "id", []), "html", null, true);
            echo "\"
                                 data-parent=\"#accordion\">
                                <div class=\"container-fluide\">
                                    <form method=\"post\">
                                        <div class=\"row\">
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                                <div class=\"card-body\">
                                                    <p class=\"text-right font-weight-bold\">
                                                        <a class=\"paddingRL\"> ";
            // line 50
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["mailoffice"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</a>
                                                    </p>
                                                    <p class=\"paddingtext paper\">";
            // line 52
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["mailoffice"], "text", [])), "html", null, true));
            echo "</p>
                                                    <p class=\"text-right font-weight-bold\">
                                                        <a class=\"paddingRL visibleEle\">Courriel
                                                            : ";
            // line 55
            echo $this->getAttribute($context["mailoffice"], "email", []);
            echo "</a>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                                <div class=\"paddingtext row  \">
                                                    <div class=\"col-12 paddingRL\">
                                                        <a href=\"mailto:";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "email", []), "html", null, true);
            echo "?subject=Merci pour%20tout%20ce%20que%20vous%20faites%20pour%20moi-Jean%20Forteroche&body=Votre message : %0D%0A%0D%0A";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "text", []), "html", null, true);
            echo "%%0D%0A%0D%0A Chères lectrices, chers lecteurs,%0D%0A%0D%0A
C%27est%20 avec%20 beaucoup%20 de%20 plaisir%20 que%20 j%27ai%20 parcouru%20 votre%20 courriel.%20 Je%20 suis%20 très%20 sensible%20 à%20 la%20 bienveillance%20 que vous%20 me%20 portez. %0D%0A%20 Votre%20 attention%20 est%20 un%20 encouragement%20 dans%20 mon%20 travail.%0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A Merci%20 pour%20tout%0D%0A %0D%0A Jean%20Forteroche\"
                                                           class=\"btn btn-card btn-bg btn-info  font-weight-bold  \"
                                                           role=\"button\" aria-pressed=\"true\">
                                                            <span class=\" visibleEle \"> Répondre&nbsp;</span>
                                                            <i data-feather=\"at-sign\"></i>
                                                        </a>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                                                name=\"classify\"
                                                                value=\"";
            // line 74
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "id", []), "html", null, true);
            echo "\">
                                                            <a class=\" paddingRL visibleEle \">Classer</a>
                                                            <i data-feather=\"archive\"></i>
                                                        </button>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                                name=\"delete\"
                                                                value=\"";
            // line 83
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailoffice"], "id", []), "html", null, true);
            echo "\">
                                                            <a class=\" paddingRL visibleEle \"> Supprimer</a>
                                                            <i data-feather=\"delete\"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mailoffice'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 96
        echo "                </div>
            </div>
            <div class=\"tab-pane fade active\" id=\"nav-archives\" role=\"tabpanel\" aria-labelledby=\"nav-archives-tab\">
                <div id=\"accordionC\">
                    ";
        // line 100
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["mailclass"]);
        foreach ($context['_seq'] as $context["_key"] => $context["mailclass"]) {
            // line 101
            echo "                        <div>
                            <div class=\"card-header\" id=\"";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailclass"], "id", []), "html", null, true);
            echo "\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col-2  col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 105
            echo $this->getAttribute($context["mailclass"], "name", []);
            echo "</a>
                                    </div>
                                    <div class=\"col-9 col-lg-8 paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 108
            echo $this->getAttribute($context["mailclass"], "title", []);
            echo "</a>
                                    </div>
                                    <div class=\"col-1 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-success font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse";
            // line 113
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailclass"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                                aria-controls=\"collapse";
            // line 114
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailclass"], "id", []), "html", null, true);
            echo "\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse";
            // line 120
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailclass"], "id", []), "html", null, true);
            echo "\" class=\"collapse\" aria-labelledby=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailclass"], "id", []), "html", null, true);
            echo "\"
                                 data-parent=\"#accordionC\">
                                <div class=\"container-fluide\">
                                    <div class=\"row\">
                                        <p class=\"paddingtext\">";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailclass"], "title", []), "html", null, true);
            echo "</p>
                                        <p class=\"paddingtext\">";
            // line 125
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["mailclass"], "text", [])), "html", null, true));
            echo "</p>
                                    </div>
                                    <div class=\"row\">
                                        <div class=\"col-2  paddingtext\">
                                            <a class=\"paddingRL\"> ";
            // line 129
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["mailclass"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</a>
                                        </div>
                                        <div class=\"col-7 paddingtext\">
                                            <a class=\"paddingRL\"> ";
            // line 132
            echo $this->getAttribute($context["mailclass"], "name", []);
            echo "</a>
                                        </div>
                                        <div class=\"col-3 paddingtext\">
                                            <form method=\"post\" action=\"index.php?p=mail_Office\">
                                                <button type=\"submit\"
                                                        class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                        name=\"delete\"
                                                        value=\"";
            // line 139
            echo twig_escape_filter($this->env, $this->getAttribute($context["mailclass"], "id", []), "html", null, true);
            echo "\">
                                                    <a class=\" paddingRL\"> Supprimer</a>
                                                    <i data-feather=\"delete\"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mailclass'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 150
        echo "                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "Admin/Office/officeMail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  272 => 150,  255 => 139,  245 => 132,  239 => 129,  232 => 125,  228 => 124,  219 => 120,  210 => 114,  206 => 113,  198 => 108,  192 => 105,  186 => 102,  183 => 101,  179 => 100,  173 => 96,  154 => 83,  142 => 74,  125 => 62,  115 => 55,  109 => 52,  104 => 50,  91 => 42,  82 => 36,  78 => 35,  70 => 30,  64 => 27,  58 => 24,  55 => 23,  51 => 22,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}

{% block textarea %}

    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Votre messagerie</h1>
    </div>

    <div class=\"col-12 shadow-lg p-2 mb-5 p-lg-5\">
        <nav>
            <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
                <a class=\"nav-item nav-link active\" id=\"nav-news-tab\" data-toggle=\"tab\" href=\"#nav-news\" role=\"tab\"
                   aria-controls=\"nav-news\" aria-selected=\"true\"><h3>Nouveaux messages</h3></a>
                <a class=\"nav-item nav-link\" id=\"nav-archives-tab\" data-toggle=\"tab\" href=\"#nav-archives\" role=\"tab\"
                   aria-controls=\"nav-archives\" aria-selected=\"false\"><h3>Archives</h3></a>
            </div>
        </nav>
        <div class=\"tab-content\" id=\"nav-tabContent\">
            <div class=\"tab-pane fade show active\" id=\"nav-news\" role=\"tabpanel\" aria-labelledby=\"nav-news-tab\">
                <div id=\"accordion\">
                    {% for mailoffice in mailoffice %}
                        <div>
                            <div class=\"card-header\" id=\"{{ mailoffice.id }}\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-5 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> {{ mailoffice.name|raw}}</a>
                                    </div>
                                    <div class=\"col col-lg-8 paddingtext\">
                                        <a class=\"paddingRL visibleEleMD\"> {{ mailoffice.title|raw }}</a>
                                    </div>
                                    <div class=\"col col-sm-5  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-success font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse{{ mailoffice.id }}\" aria-expanded=\"true\"
                                                aria-controls=\"collapse{{ mailoffice.id }}\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse{{ mailoffice.id }}\" class=\"collapse\" aria-labelledby=\"{{ mailoffice.id }}\"
                                 data-parent=\"#accordion\">
                                <div class=\"container-fluide\">
                                    <form method=\"post\">
                                        <div class=\"row\">
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                                <div class=\"card-body\">
                                                    <p class=\"text-right font-weight-bold\">
                                                        <a class=\"paddingRL\"> {{ mailoffice.date|date_modify ( \"+1 day\" )| date ( \"m/d/Y\"  ) }}</a>
                                                    </p>
                                                    <p class=\"paddingtext paper\">{{ mailoffice.text|striptags|nl2br }}</p>
                                                    <p class=\"text-right font-weight-bold\">
                                                        <a class=\"paddingRL visibleEle\">Courriel
                                                            : {{ mailoffice.email|raw }}</a>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                                <div class=\"paddingtext row  \">
                                                    <div class=\"col-12 paddingRL\">
                                                        <a href=\"mailto:{{ mailoffice.email }}?subject=Merci pour%20tout%20ce%20que%20vous%20faites%20pour%20moi-Jean%20Forteroche&body=Votre message : %0D%0A%0D%0A{{ mailoffice.text }}%%0D%0A%0D%0A Chères lectrices, chers lecteurs,%0D%0A%0D%0A
C%27est%20 avec%20 beaucoup%20 de%20 plaisir%20 que%20 j%27ai%20 parcouru%20 votre%20 courriel.%20 Je%20 suis%20 très%20 sensible%20 à%20 la%20 bienveillance%20 que vous%20 me%20 portez. %0D%0A%20 Votre%20 attention%20 est%20 un%20 encouragement%20 dans%20 mon%20 travail.%0D%0A %0D%0A %0D%0A %0D%0A %0D%0A %0D%0A Merci%20 pour%20tout%0D%0A %0D%0A Jean%20Forteroche\"
                                                           class=\"btn btn-card btn-bg btn-info  font-weight-bold  \"
                                                           role=\"button\" aria-pressed=\"true\">
                                                            <span class=\" visibleEle \"> Répondre&nbsp;</span>
                                                            <i data-feather=\"at-sign\"></i>
                                                        </a>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                                                name=\"classify\"
                                                                value=\"{{ mailoffice.id }}\">
                                                            <a class=\" paddingRL visibleEle \">Classer</a>
                                                            <i data-feather=\"archive\"></i>
                                                        </button>
                                                    </div>
                                                    <div class=\"col-12 paddingRL\">
                                                        <button type=\"submit\"
                                                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                                name=\"delete\"
                                                                value=\"{{ mailoffice.id }}\">
                                                            <a class=\" paddingRL visibleEle \"> Supprimer</a>
                                                            <i data-feather=\"delete\"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
            <div class=\"tab-pane fade active\" id=\"nav-archives\" role=\"tabpanel\" aria-labelledby=\"nav-archives-tab\">
                <div id=\"accordionC\">
                    {% for mailclass in mailclass %}
                        <div>
                            <div class=\"card-header\" id=\"{{ mailclass.id }}\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col-2  col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> {{ mailclass.name|raw }}</a>
                                    </div>
                                    <div class=\"col-9 col-lg-8 paddingtext\">
                                        <a class=\"paddingRL\"> {{ mailclass.title|raw }}</a>
                                    </div>
                                    <div class=\"col-1 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-success font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse{{ mailclass.id }}\" aria-expanded=\"true\"
                                                aria-controls=\"collapse{{ mailclass.id }}\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse{{ mailclass.id }}\" class=\"collapse\" aria-labelledby=\"{{ mailclass.id }}\"
                                 data-parent=\"#accordionC\">
                                <div class=\"container-fluide\">
                                    <div class=\"row\">
                                        <p class=\"paddingtext\">{{ mailclass.title }}</p>
                                        <p class=\"paddingtext\">{{ mailclass.text|striptags|nl2br }}</p>
                                    </div>
                                    <div class=\"row\">
                                        <div class=\"col-2  paddingtext\">
                                            <a class=\"paddingRL\"> {{ mailclass.date| date_modify ( \"+1 day\" )| date ( \"m/d/Y\" ) }}</a>
                                        </div>
                                        <div class=\"col-7 paddingtext\">
                                            <a class=\"paddingRL\"> {{ mailclass.name|raw }}</a>
                                        </div>
                                        <div class=\"col-3 paddingtext\">
                                            <form method=\"post\" action=\"index.php?p=mail_Office\">
                                                <button type=\"submit\"
                                                        class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                        name=\"delete\"
                                                        value=\"{{ mailclass.id }}\">
                                                    <a class=\" paddingRL\"> Supprimer</a>
                                                    <i data-feather=\"delete\"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
        </div>
    </div>
{% endblock %}
", "Admin/Office/officeMail.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Admin\\Office\\officeMail.html.twig");
    }
}
