<?php

/* Admin/NewWrite/officeWriteNewText.html.twig */
class __TwigTemplate_048b9d1a574777e6c789c25a1c06b863a40cb1ed33a8bfec149c722d5fcab9f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/NewWrite/officeWriteNewText.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_textarea($context, array $blocks = [])
    {
        // line 5
        echo "    <br/>

    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Publications</h1>
    </div>

    <form method=\"post\">
        <div class=\" row justify-content-between font-weight-bold \">
            <div class=\"col-4\">
                <label for=\"ChapDashboard\" class=\"paddingtext font-weight-bold\">Chapitre</label>
                <input type=\"number\" value=\"0\" name=\"ChapDashboard\">
            </div>
            <div class=\"col-3\">
                <div class=\"form-group\">
                    <div class=\"row\">
                        <div class=\"col-6 form-check form-check-inline\">
                            <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status0\" value=\"0\"
                                   checked>
                            <label class=\"form-check-label\" for=\"is_status0\">Brouillon
                            </label>
                        </div>
                        <div class=\"col-6 form-check form-check-inline  \">
                            <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status1\" value=\"1\">
                            <label class=\"form-check-label\" for=\"is_status1\">Editer
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-10\">
                <label for=\"TitleDashboard\" class=\"paddingtext font-weight-bold\">Titre</label>
                <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" required>
            </div>
        </div>

        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-11\">
                <label for=\"TextDashboard\" class=\"paddingtext font-weight-bold\"> Texte </label>
                <textarea class=\"form-control textarea\" id=\"adminTextarea\" rows=\"20\"
                          name=\"TextDashboard\"></textarea>
            </div>
        </div>
        <div class=\"row justify-content-center \">
            <div class=\"col-10\">
                <input type=\"hidden\" name=\"csrf_token\" value=\"";
        // line 51
        echo twig_escape_filter($this->env, ($context["csrf_token"] ?? null), "html", null, true);
        echo "\"/>

                <div class=\"paddingtext row \">

                    <div class=\"col-4 col-xl-2 paddingRL\">
                                               <button type=\"submit\"
                                class=\"btn btn-card btn-bg btn-warning font-weight-bold \"
                                name=\"postSave\"
                                value=\"\">
                            <a class=\" visibleEleMD paddingRL\">Enregistrer</a>
                            <i data-feather=\"save\"></i>
                        </button>
                    </div>
                    <div class=\"col-2 paddingRL\">
                        <input class=\"btn btn-secondary\" type=\"reset\" value=\"Effacer\"/>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <wbr/>
";
    }

    public function getTemplateName()
    {
        return "Admin/NewWrite/officeWriteNewText.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 51,  31 => 5,  28 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}


{% block textarea %}
    <br/>

    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Publications</h1>
    </div>

    <form method=\"post\">
        <div class=\" row justify-content-between font-weight-bold \">
            <div class=\"col-4\">
                <label for=\"ChapDashboard\" class=\"paddingtext font-weight-bold\">Chapitre</label>
                <input type=\"number\" value=\"0\" name=\"ChapDashboard\">
            </div>
            <div class=\"col-3\">
                <div class=\"form-group\">
                    <div class=\"row\">
                        <div class=\"col-6 form-check form-check-inline\">
                            <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status0\" value=\"0\"
                                   checked>
                            <label class=\"form-check-label\" for=\"is_status0\">Brouillon
                            </label>
                        </div>
                        <div class=\"col-6 form-check form-check-inline  \">
                            <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status1\" value=\"1\">
                            <label class=\"form-check-label\" for=\"is_status1\">Editer
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-10\">
                <label for=\"TitleDashboard\" class=\"paddingtext font-weight-bold\">Titre</label>
                <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" required>
            </div>
        </div>

        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-11\">
                <label for=\"TextDashboard\" class=\"paddingtext font-weight-bold\"> Texte </label>
                <textarea class=\"form-control textarea\" id=\"adminTextarea\" rows=\"20\"
                          name=\"TextDashboard\"></textarea>
            </div>
        </div>
        <div class=\"row justify-content-center \">
            <div class=\"col-10\">
                <input type=\"hidden\" name=\"csrf_token\" value=\"{{ csrf_token }}\"/>

                <div class=\"paddingtext row \">

                    <div class=\"col-4 col-xl-2 paddingRL\">
                                               <button type=\"submit\"
                                class=\"btn btn-card btn-bg btn-warning font-weight-bold \"
                                name=\"postSave\"
                                value=\"\">
                            <a class=\" visibleEleMD paddingRL\">Enregistrer</a>
                            <i data-feather=\"save\"></i>
                        </button>
                    </div>
                    <div class=\"col-2 paddingRL\">
                        <input class=\"btn btn-secondary\" type=\"reset\" value=\"Effacer\"/>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <wbr/>
{% endblock %}




", "Admin/NewWrite/officeWriteNewText.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Admin\\NewWrite\\officeWriteNewText.html.twig");
    }
}
