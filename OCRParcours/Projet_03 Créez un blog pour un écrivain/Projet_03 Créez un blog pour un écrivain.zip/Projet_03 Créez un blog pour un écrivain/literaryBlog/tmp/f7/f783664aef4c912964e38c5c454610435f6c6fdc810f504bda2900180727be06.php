<?php

/* Admin/Modification/textPostsModif.html.twig */
class __TwigTemplate_383bf78e91169a9a14398aaaac831f65124cded91c1027b7a50b727c2329e28f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/Modification/textPostsModif.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_textarea($context, array $blocks = [])
    {
        // line 4
        echo "    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Publications</h1>
    </div>


    <form method=\"post\">
        <input type=\"hidden\" name=\"csrf_token\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, ($context["csrf_token"] ?? null), "html", null, true);
        echo "\"/>
        <div class=\" row justify-content-between font-weight-bold \">
            <div class=\"col-4\">
                <label for=\"ChapDashboard\" class=\"paddingtext font-weight-bold\">Chapitre</label>
                <input type=\"number\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["chapitre"] ?? null), "chapter", []), "html", null, true);
        echo "\" name=\"ChapDashboard\">
            </div>
            <div class=\"col-3\">
                <div class=\"form-group\">
                    <div class=\"row\">
                        <div class=\"col-6 form-check form-check-inline\">
                            <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status0\" value=\"0\"
                                    ";
        // line 22
        echo ((($this->getAttribute(($context["chapitre"] ?? null), "classify", []) == 0)) ? ("checked") : (""));
        echo " >
                            <label class=\"form-check-label\" for=\"is_status0\">Brouillon
                            </label>
                        </div>
                        <div class=\"col-6 form-check form-check-inline  \">
                            <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status1\"
                                   value=\"1\" ";
        // line 28
        echo ((($this->getAttribute(($context["chapitre"] ?? null), "classify", []) == 1)) ? ("checked") : (""));
        echo " >
                            <label class=\"form-check-label\" for=\"is_status1\">Editer
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-10\">
                <label for=\"TitleDashboard\" class=\"paddingtext font-weight-bold\">Titre</label>
                <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" value=\"";
        // line 39
        echo twig_escape_filter($this->env, strip_tags($this->getAttribute(($context["chapitre"] ?? null), "title", [])), "html", null, true);
        echo "\"
                       required>
            </div>
        </div>

        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-11\">
                <label for=\"TextDashboard\" class=\"paddingtext font-weight-bold\">Texte</label>
                <textarea class=\"form-control textarea\" id=\"adminTextarea\" rows=\"20\"
                          name=\"TextDashboard\">";
        // line 48
        echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute(($context["chapitre"] ?? null), "text", [])), "html", null, true));
        echo "</textarea>
            </div>
        </div>
        <div class=\"row justify-content-center \">
            <div class=\"col-10\">
                <div class=\"paddingtext row \">
                    <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                        <a href=\"index.php?p=posts_admin&id=";
        // line 55
        echo nl2br(twig_escape_filter($this->env, $this->getAttribute(($context["chapitre"] ?? null), "id", []), "html", null, true));
        echo "\">
                            <button type=\"submit\"
                                    class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                    name=\"postModify\"
                                    value=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->getAttribute(($context["chapitre"] ?? null), "id", []), "html", null, true);
        echo "\">
                                <a class=\" paddingRL\">Modifier</a>
                                <i data-feather=\"edit-2\"></i>
                            </button>
                        </a>
                    </div>
                    <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                        <button type=\"submit\"
                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                name=\"delete\"
                                value=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->getAttribute(($context["chapitre"] ?? null), "id", []), "html", null, true);
        echo "\">
                            <a class=\" paddingRL\"> Supprimer</a>
                            <i data-feather=\"delete\"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    <wbr/>

";
    }

    public function getTemplateName()
    {
        return "Admin/Modification/textPostsModif.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 69,  109 => 59,  102 => 55,  92 => 48,  80 => 39,  66 => 28,  57 => 22,  47 => 15,  40 => 11,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}

{% block textarea %}
    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Publications</h1>
    </div>


    <form method=\"post\">
        <input type=\"hidden\" name=\"csrf_token\" value=\"{{ csrf_token }}\"/>
        <div class=\" row justify-content-between font-weight-bold \">
            <div class=\"col-4\">
                <label for=\"ChapDashboard\" class=\"paddingtext font-weight-bold\">Chapitre</label>
                <input type=\"number\" value=\"{{ chapitre.chapter }}\" name=\"ChapDashboard\">
            </div>
            <div class=\"col-3\">
                <div class=\"form-group\">
                    <div class=\"row\">
                        <div class=\"col-6 form-check form-check-inline\">
                            <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status0\" value=\"0\"
                                    {{ (chapitre.classify == 0)? 'checked':'' }} >
                            <label class=\"form-check-label\" for=\"is_status0\">Brouillon
                            </label>
                        </div>
                        <div class=\"col-6 form-check form-check-inline  \">
                            <input class=\"form-check-input\" type=\"radio\" name=\"is_status\" id=\"is_status1\"
                                   value=\"1\" {{ (chapitre.classify == 1)?'checked':'' }} >
                            <label class=\"form-check-label\" for=\"is_status1\">Editer
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-10\">
                <label for=\"TitleDashboard\" class=\"paddingtext font-weight-bold\">Titre</label>
                <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" value=\"{{ chapitre.title|striptags }}\"
                       required>
            </div>
        </div>

        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-11\">
                <label for=\"TextDashboard\" class=\"paddingtext font-weight-bold\">Texte</label>
                <textarea class=\"form-control textarea\" id=\"adminTextarea\" rows=\"20\"
                          name=\"TextDashboard\">{{ chapitre.text|striptags | nl2br }}</textarea>
            </div>
        </div>
        <div class=\"row justify-content-center \">
            <div class=\"col-10\">
                <div class=\"paddingtext row \">
                    <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                        <a href=\"index.php?p=posts_admin&id={{ chapitre.id |nl2br }}\">
                            <button type=\"submit\"
                                    class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                    name=\"postModify\"
                                    value=\"{{ chapitre.id }}\">
                                <a class=\" paddingRL\">Modifier</a>
                                <i data-feather=\"edit-2\"></i>
                            </button>
                        </a>
                    </div>
                    <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                        <button type=\"submit\"
                                class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                name=\"delete\"
                                value=\"{{ chapitre.id }}\">
                            <a class=\" paddingRL\"> Supprimer</a>
                            <i data-feather=\"delete\"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    <wbr/>

{% endblock %}", "Admin/Modification/textPostsModif.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Admin\\Modification\\textPostsModif.html.twig");
    }
}
