<?php

/* Admin/Office/officeComment.html.twig */
class __TwigTemplate_9d8b83c3109c89e9505de0eafe415f3745e74e8d60b0df08d98e449b29f4b4b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/Office/officeComment.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_textarea($context, array $blocks = [])
    {
        // line 4
        echo "    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Commentaires</h1>
    </div>
    <div class=\"col-12 shadow-lg p-2 mb-5 p-lg-5\">
        <nav>
            <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
                <a class=\"nav-item nav-link active\" id=\"nav-comments-tab\" data-toggle=\"tab\" href=\"#nav-comments\"
                   role=\"tab\"
                   aria-controls=\"nav-comments\" aria-selected=\"true\"><h3>Les commentaires</h3></a>
                <a class=\"nav-item nav-link\" id=\"nav-report-tab\" data-toggle=\"tab\" href=\"#nav-report\" role=\"tab\"
                   aria-controls=\"nav-report\" aria-selected=\"false\"><h3>Commentaires signalés</h3></a>
            </div>
        </nav>
        <div class=\"tab-content\" id=\"nav-tabContent\">
            <div class=\"tab-pane fade show active\" id=\"nav-comments\" role=\"tabpanel\" aria-labelledby=\"nav-comments-tab\">
                <div id=\"accordion\">

                    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["commentoffice"]);
        foreach ($context['_seq'] as $context["_key"] => $context["commentoffice"]) {
            // line 23
            echo "                        <div>
                            <div class=\"card-header\" id=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 27
            echo $this->getAttribute($context["commentoffice"], "pseudo", []);
            echo "</a>
                                    </div>
                                    <div class=\"col-3 visibleEleMD paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 30
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["commentoffice"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</a>
                                    </div>
                                    <div class=\" col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a href=\"index.php?p=post_show&id=";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id_chapter", []), "html", null, true);
            echo "\"
                                           target=\"_blank\">
                                            <button class=\"btn greenLink \">Chapitre</button>
                                        </a>
                                    </div>
                                    <div class=\"col col-sm-4  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-warning font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                                aria-controls=\"collapse";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\" class=\"collapse\"
                                 aria-labelledby=\"";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\" data-parent=\"#accordion\">
                                <div class=\"container-fluide\">
                                    <div class=\"row paddingtext\">
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                            <p>";
            // line 53
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["commentoffice"], "comment", [])), "html", null, true));
            echo "</p>
                                        </div>
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                            <form method=\"post\" action=\"index.php?p=comment_Office\">
                                                <button type=\"submit\"
                                                        class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                        name=\"delete\"
                                                        value=\"";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\">
                                                    <a class=\" paddingRL visibleEle \"> Supprimer</a>
                                                    <i data-feather=\"delete\"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['commentoffice'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "                </div>
            </div>
            <div class=\"tab-pane fade active\" id=\"nav-report\" role=\"tabpanel\" aria-labelledby=\"nav-report-tab\">
                <div id=\"accordionR\">
                    ";
        // line 75
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["commentreport"]);
        foreach ($context['_seq'] as $context["_key"] => $context["commentreport"]) {
            // line 76
            echo "                        <div>
                            <div class=\"card-header\" id=\"";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 80
            echo $this->getAttribute($context["commentreport"], "pseudo", []);
            echo "</a>
                                    </div>
                                    <div class=\"col-3 visibleEleMD paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 83
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["commentreport"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</a>
                                    </div>
                                    <div class=\" col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a href=\"index.php?p=post_show&id=";
            // line 86
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id_chapter", []), "html", null, true);
            echo "\"
                                           target=\"_blank\">
                                            <button type=\"button\" class=\"btn btn-light greenLink \">Chapitre</button>
                                        </a>
                                    </div>
                                    <div class=\"col col-sm-4  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-danger font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                                aria-controls=\"collapse";
            // line 95
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse";
            // line 101
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\" class=\"collapse\"
                                 aria-labelledby=\"";
            // line 102
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\"
                                 data-parent=\"#accordionR\">
                                <div class=\"container-fluide\">
                                    <form method=\"post\" action=\"index.php?p=comment_Office\">
                                        <div class=\"row paddingtext\">
                                            <div class=\"col-9\">
                                                <p>";
            // line 108
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["commentreport"], "comment", [])), "html", null, true));
            echo "</p>
                                            </div>
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                                <div class=\"col-12 paddingRL\">
                                                    <button type=\"submit\"
                                                            class=\"btn btn-card btn-bg btn-success font-weight-bold \"
                                                            name=\"classify\"
                                                            value=\"";
            // line 115
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\">
                                                        <a class=\" paddingRL visibleEle\">Garder</a>
                                                        <i data-feather=\"check\"></i>
                                                    </button>
                                                </div>
                                                <div class=\"col-12 paddingRL\">
                                                    <button type=\"submit\"
                                                            class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                            name=\"delete\"
                                                            value=\"";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\">
                                                        <a class=\" paddingRL visibleEle\"> Supprimer</a>
                                                        <i data-feather=\"delete\"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['commentreport'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 136
        echo "                </div>
            </div>
        </div>
    </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "Admin/Office/officeComment.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  246 => 136,  228 => 124,  216 => 115,  206 => 108,  197 => 102,  193 => 101,  184 => 95,  180 => 94,  169 => 86,  163 => 83,  157 => 80,  151 => 77,  148 => 76,  144 => 75,  138 => 71,  121 => 60,  111 => 53,  104 => 49,  100 => 48,  91 => 42,  87 => 41,  76 => 33,  70 => 30,  64 => 27,  58 => 24,  55 => 23,  51 => 22,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}

{% block textarea %}
    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Commentaires</h1>
    </div>
    <div class=\"col-12 shadow-lg p-2 mb-5 p-lg-5\">
        <nav>
            <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
                <a class=\"nav-item nav-link active\" id=\"nav-comments-tab\" data-toggle=\"tab\" href=\"#nav-comments\"
                   role=\"tab\"
                   aria-controls=\"nav-comments\" aria-selected=\"true\"><h3>Les commentaires</h3></a>
                <a class=\"nav-item nav-link\" id=\"nav-report-tab\" data-toggle=\"tab\" href=\"#nav-report\" role=\"tab\"
                   aria-controls=\"nav-report\" aria-selected=\"false\"><h3>Commentaires signalés</h3></a>
            </div>
        </nav>
        <div class=\"tab-content\" id=\"nav-tabContent\">
            <div class=\"tab-pane fade show active\" id=\"nav-comments\" role=\"tabpanel\" aria-labelledby=\"nav-comments-tab\">
                <div id=\"accordion\">

                    {% for commentoffice in commentoffice %}
                        <div>
                            <div class=\"card-header\" id=\"{{ commentoffice.id }}\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> {{ commentoffice.pseudo|raw }}</a>
                                    </div>
                                    <div class=\"col-3 visibleEleMD paddingtext\">
                                        <a class=\"paddingRL\"> {{ commentoffice.date|date_modify ( \"+1 day\" )| date ( \"m/d/Y\"  ) }}</a>
                                    </div>
                                    <div class=\" col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a href=\"index.php?p=post_show&id={{ commentoffice.id_chapter }}\"
                                           target=\"_blank\">
                                            <button class=\"btn greenLink \">Chapitre</button>
                                        </a>
                                    </div>
                                    <div class=\"col col-sm-4  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-warning font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse{{ commentoffice.id }}\" aria-expanded=\"true\"
                                                aria-controls=\"collapse{{ commentoffice.id }}\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse{{ commentoffice.id }}\" class=\"collapse\"
                                 aria-labelledby=\"{{ commentoffice.id }}\" data-parent=\"#accordion\">
                                <div class=\"container-fluide\">
                                    <div class=\"row paddingtext\">
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                            <p>{{ commentoffice.comment|striptags|nl2br }}</p>
                                        </div>
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                            <form method=\"post\" action=\"index.php?p=comment_Office\">
                                                <button type=\"submit\"
                                                        class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                        name=\"delete\"
                                                        value=\"{{ commentoffice.id }}\">
                                                    <a class=\" paddingRL visibleEle \"> Supprimer</a>
                                                    <i data-feather=\"delete\"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
            <div class=\"tab-pane fade active\" id=\"nav-report\" role=\"tabpanel\" aria-labelledby=\"nav-report-tab\">
                <div id=\"accordionR\">
                    {% for commentreport in commentreport %}
                        <div>
                            <div class=\"card-header\" id=\"{{ commentreport.id }}\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> {{ commentreport.pseudo|raw }}</a>
                                    </div>
                                    <div class=\"col-3 visibleEleMD paddingtext\">
                                        <a class=\"paddingRL\"> {{ commentreport.date|date_modify ( \"+1 day\" )| date ( \"m/d/Y\"  ) }}</a>
                                    </div>
                                    <div class=\" col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a href=\"index.php?p=post_show&id={{ commentreport.id_chapter }}\"
                                           target=\"_blank\">
                                            <button type=\"button\" class=\"btn btn-light greenLink \">Chapitre</button>
                                        </a>
                                    </div>
                                    <div class=\"col col-sm-4  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-danger font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse{{ commentreport.id }}\" aria-expanded=\"true\"
                                                aria-controls=\"collapse{{ commentreport.id }}\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse{{ commentreport.id }}\" class=\"collapse\"
                                 aria-labelledby=\"{{ commentreport.id }}\"
                                 data-parent=\"#accordionR\">
                                <div class=\"container-fluide\">
                                    <form method=\"post\" action=\"index.php?p=comment_Office\">
                                        <div class=\"row paddingtext\">
                                            <div class=\"col-9\">
                                                <p>{{ commentreport.comment|striptags|nl2br }}</p>
                                            </div>
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                                <div class=\"col-12 paddingRL\">
                                                    <button type=\"submit\"
                                                            class=\"btn btn-card btn-bg btn-success font-weight-bold \"
                                                            name=\"classify\"
                                                            value=\"{{ commentreport.id }}\">
                                                        <a class=\" paddingRL visibleEle\">Garder</a>
                                                        <i data-feather=\"check\"></i>
                                                    </button>
                                                </div>
                                                <div class=\"col-12 paddingRL\">
                                                    <button type=\"submit\"
                                                            class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                            name=\"delete\"
                                                            value=\"{{ commentreport.id }}\">
                                                        <a class=\" paddingRL visibleEle\"> Supprimer</a>
                                                        <i data-feather=\"delete\"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
        </div>
    </div>
    </div>
{% endblock %}
", "Admin/Office/officeComment.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Admin\\Office\\officeComment.html.twig");
    }
}
