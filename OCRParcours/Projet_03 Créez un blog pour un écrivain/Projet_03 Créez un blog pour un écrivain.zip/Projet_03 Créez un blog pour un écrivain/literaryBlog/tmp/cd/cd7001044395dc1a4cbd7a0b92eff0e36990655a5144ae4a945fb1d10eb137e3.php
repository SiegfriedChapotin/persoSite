<?php

/* Admin/Modification/textHeadingModif.html.twig */
class __TwigTemplate_c57176a41420c13248fc36cb5553ce2d761b790ac0bd7eeceb9f047fb8715ee6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/Modification/textHeadingModif.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_textarea($context, array $blocks = [])
    {
        // line 4
        echo "
    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Page d'accueil</h1>
    </div>
    <form method=\"post\">
        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-10\">
                <label for=\"TitleDashboard\">Titre</label>
                <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, strip_tags($this->getAttribute(($context["heading"] ?? null), "title", [])), "html", null, true);
        echo "\"
                       required>
            </div>
        </div>
        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-11\">
                <label for=\"TextDashboard\"> Texte </label>
                <textarea class=\"form-control textarea\" id=\"adminTextarea\" rows=\"20\"
                          name=\"TextDashboard\">";
        // line 21
        echo $this->getAttribute(($context["heading"] ?? null), "text", []);
        echo "</textarea>
            </div>
        </div>
        <div class=\"row justify-content-center \">
            <div class=\"col-10\">
                <input type=\"hidden\" name=\"csrf_token\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, ($context["csrf_token"] ?? null), "html", null, true);
        echo "\"/>

                <div class=\"paddingtext row  \">
                    <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                        <a href=\"index.php?p=posts_admin&id=";
        // line 30
        echo nl2br(twig_escape_filter($this->env, $this->getAttribute(($context["heading"] ?? null), "id", []), "html", null, true));
        echo "\">
                            <button type=\"submit\"
                                    class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                    name=\"postModify\"
                                    value=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute(($context["heading"] ?? null), "id", []), "html", null, true);
        echo "\">
                                <a class=\" paddingRL\">Modifier</a>
                                <i data-feather=\"edit-2\"></i>
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>


";
    }

    public function getTemplateName()
    {
        return "Admin/Modification/textHeadingModif.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 34,  68 => 30,  61 => 26,  53 => 21,  42 => 13,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}

{% block textarea %}

    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Page d'accueil</h1>
    </div>
    <form method=\"post\">
        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-10\">
                <label for=\"TitleDashboard\">Titre</label>
                <input class=\"form-control\" type=\"text\" name=\"TitleDashboard\" value=\"{{ heading.title|striptags }}\"
                       required>
            </div>
        </div>
        <div class=\" row justify-content-center font-weight-bold \">
            <div class=\"col-11\">
                <label for=\"TextDashboard\"> Texte </label>
                <textarea class=\"form-control textarea\" id=\"adminTextarea\" rows=\"20\"
                          name=\"TextDashboard\">{{ heading.text|raw }}</textarea>
            </div>
        </div>
        <div class=\"row justify-content-center \">
            <div class=\"col-10\">
                <input type=\"hidden\" name=\"csrf_token\" value=\"{{ csrf_token }}\"/>

                <div class=\"paddingtext row  \">
                    <div class=\"col-12 col-sm-5 col-md-4 col-lg-4 col-xl-3 paddingRL\">
                        <a href=\"index.php?p=posts_admin&id={{ heading.id |nl2br }}\">
                            <button type=\"submit\"
                                    class=\"btn btn-card btn-bg btn-primary font-weight-bold \"
                                    name=\"postModify\"
                                    value=\"{{ heading.id }}\">
                                <a class=\" paddingRL\">Modifier</a>
                                <i data-feather=\"edit-2\"></i>
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>


{% endblock %}", "Admin/Modification/textHeadingModif.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Admin\\Modification\\textHeadingModif.html.twig");
    }
}
