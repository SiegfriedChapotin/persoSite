<?php

/* Posts/contact.html.twig */
class __TwigTemplate_30785455aecbaabea97e738d54adfc7a53390ac591b55a14665e8e6113000817 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/GenericLayout/main.html.twig", "Posts/contact.html.twig", 1);
        $this->blocks = [
            'contact' => [$this, 'block_contact'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/GenericLayout/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_contact($context, array $blocks = [])
    {
        // line 6
        echo "
    <div class=\"shadow-lg p-5 mb-5 bg-gradient-warning rounded headingheight\">
        <h1>Me contacter ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? null), "request", []), "cookies", []), "get", [0 => "authToken"], "method"), "html", null, true);
        echo "</h1>
        <br/>
    </div>


    <form method=\"post\">
        <div class=\"form-group\">
            <input type=\"hidden\" id=\"recaptcha\" name=\"recaptcha\">

            <label for=\"NameMail\" class=\"paddingtext font-weight-bold\">Votre Nom</label>
            <textarea class=\"form-control\" id=\"NameMail\" maxlength=\"30\" name=\"NameMail\" required></textarea>

            <label for=\"EmailMail\" class=\"padding font-weight-bold\">Votre courriel</label>
            <input class=\"form-control\" type=\"email\"  id=\"EmailMail\" name=\"EmailMail\" required>

            <label for=\"TitreMail\" class=\"padding font-weight-bold\" >Titre</label>
            <input class=\"form-control\" type=\"text\" id=\"TitreMail\" maxlength=\"60\" name=\"TitreMail\" required>

            <label for=\"TextMail\" class=\"padding font-weight-bold\"> Votre message </label>
            <textarea class=\"form-control textarea\" id=\"TextMail\" rows=\"20\" name=\"TextMail\"></textarea>
        </div>
        <div>
            <p><input type=\"checkbox\" required name=\"terms\"> J'ai lu et accepte la Politique de confidentialité. Voir
                les <a href=\"index.php?p=rgpd_show\" target=\"_blank\">
                    <span class=\"badge badge-dark \"> Mentions légales RGPD</span></a>
            </p>
        </div>
        <div>
            <input type=\"hidden\" name=\"csrf_token\" value=\"";
        // line 36
        echo twig_escape_filter($this->env, ($context["csrf_token"] ?? null), "html", null, true);
        echo "\"/>
            <input class=\"btn btn-success\" type=\"submit\" name=\"Envoyer\" value=\"Envoyer\"/>
            <input class=\"btn btn-secondary\" type=\"reset\" value=\"Effacer\"/>

        </div>
    </form>


    <wbr/>

";
    }

    public function getTemplateName()
    {
        return "Posts/contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 36,  35 => 8,  31 => 6,  28 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Layout/GenericLayout/main.html.twig'  %}



{% block contact %}

    <div class=\"shadow-lg p-5 mb-5 bg-gradient-warning rounded headingheight\">
        <h1>Me contacter {{app.request.cookies.get(\"authToken\")}}</h1>
        <br/>
    </div>


    <form method=\"post\">
        <div class=\"form-group\">
            <input type=\"hidden\" id=\"recaptcha\" name=\"recaptcha\">

            <label for=\"NameMail\" class=\"paddingtext font-weight-bold\">Votre Nom</label>
            <textarea class=\"form-control\" id=\"NameMail\" maxlength=\"30\" name=\"NameMail\" required></textarea>

            <label for=\"EmailMail\" class=\"padding font-weight-bold\">Votre courriel</label>
            <input class=\"form-control\" type=\"email\"  id=\"EmailMail\" name=\"EmailMail\" required>

            <label for=\"TitreMail\" class=\"padding font-weight-bold\" >Titre</label>
            <input class=\"form-control\" type=\"text\" id=\"TitreMail\" maxlength=\"60\" name=\"TitreMail\" required>

            <label for=\"TextMail\" class=\"padding font-weight-bold\"> Votre message </label>
            <textarea class=\"form-control textarea\" id=\"TextMail\" rows=\"20\" name=\"TextMail\"></textarea>
        </div>
        <div>
            <p><input type=\"checkbox\" required name=\"terms\"> J'ai lu et accepte la Politique de confidentialité. Voir
                les <a href=\"index.php?p=rgpd_show\" target=\"_blank\">
                    <span class=\"badge badge-dark \"> Mentions légales RGPD</span></a>
            </p>
        </div>
        <div>
            <input type=\"hidden\" name=\"csrf_token\" value=\"{{ csrf_token }}\"/>
            <input class=\"btn btn-success\" type=\"submit\" name=\"Envoyer\" value=\"Envoyer\"/>
            <input class=\"btn btn-secondary\" type=\"reset\" value=\"Effacer\"/>

        </div>
    </form>


    <wbr/>

{% endblock %}", "Posts/contact.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Posts\\contact.html.twig");
    }
}
