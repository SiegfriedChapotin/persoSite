<?php

/* Admin/Security/officeConnection.html.twig */
class __TwigTemplate_2739a6fca72ba8bfe6cbb79073edc4eb3bcc25f4d74f2940ef0ff5a52378cd5c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/GenericLayout/main.html.twig", "Admin/Security/officeConnection.html.twig", 1);
        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/GenericLayout/main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "
    <div id=\"connect\" class=\"text-center\">

        <form action=\"\" method=\"post\" class=\"form-signin\">
            <img class=\"mb-4\" src=\"img\\ico.png\" alt=\"\" width=\"72\" height=\"72\">
            <h1 class=\"h3 mb-3 font-weight-normal\">Bonjour, </h1>
            <br/>
            <div class=\"form-label-group\">
                <label for=\"username\" class=\"sr-only\">Pseudo</label>
                <input type=\"text\" id=\"inputName\" class=\"form-control\" name=\"username\" placeholder=\"Votre pseudo\"
                       required autofocus>
                <br/>

                <label for=\"password\" class=\"sr-only\">Mot de passe</label>
                <input type=\"password\" id=\"inputPassword\" class=\"form-control\" name=\"password\"
                       placeholder=\"Mot de passe\" required>
            </div>
            ";
        // line 21
        if ( !twig_test_empty(($context["Errors"] ?? null))) {
            // line 22
            echo "                <div style=\"color: red;\">
                    ";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute(($context["Errors"] ?? null), 0, []), "html", null, true);
            echo "
                </div>
            ";
        }
        // line 26
        echo "            <wbr/>
            <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Connexion</button>
        </form>
    </div>

";
    }

    public function getTemplateName()
    {
        return "Admin/Security/officeConnection.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 26,  55 => 23,  52 => 22,  50 => 21,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'Layout/GenericLayout/main.html.twig' %}

{% block content %}

    <div id=\"connect\" class=\"text-center\">

        <form action=\"\" method=\"post\" class=\"form-signin\">
            <img class=\"mb-4\" src=\"img\\ico.png\" alt=\"\" width=\"72\" height=\"72\">
            <h1 class=\"h3 mb-3 font-weight-normal\">Bonjour, </h1>
            <br/>
            <div class=\"form-label-group\">
                <label for=\"username\" class=\"sr-only\">Pseudo</label>
                <input type=\"text\" id=\"inputName\" class=\"form-control\" name=\"username\" placeholder=\"Votre pseudo\"
                       required autofocus>
                <br/>

                <label for=\"password\" class=\"sr-only\">Mot de passe</label>
                <input type=\"password\" id=\"inputPassword\" class=\"form-control\" name=\"password\"
                       placeholder=\"Mot de passe\" required>
            </div>
            {% if Errors is not empty %}
                <div style=\"color: red;\">
                    {{ Errors.0 }}
                </div>
            {% endif %}
            <wbr/>
            <button class=\"btn btn-lg btn-primary btn-block\" type=\"submit\">Connexion</button>
        </form>
    </div>

{% endblock %}




", "Admin/Security/officeConnection.html.twig", "C:\\wamp64\\www\\literaryBlog\\app\\Views\\Admin\\Security\\officeConnection.html.twig");
    }
}
