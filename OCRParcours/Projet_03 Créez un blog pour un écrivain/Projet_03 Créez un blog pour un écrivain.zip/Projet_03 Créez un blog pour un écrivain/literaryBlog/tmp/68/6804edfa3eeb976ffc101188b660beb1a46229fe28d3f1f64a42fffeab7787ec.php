<?php

/* Admin/Office/officeComment.html.twig */
class __TwigTemplate_d9e3b45e37e2ad9b038e083cf89f82be5e4e14bb8ed3746c3fdd46236b1b2b52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("Layout/layoutdashboard.html.twig", "Admin/Office/officeComment.html.twig", 1);
        $this->blocks = [
            'textarea' => [$this, 'block_textarea'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "Layout/layoutdashboard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_textarea($context, array $blocks = [])
    {
        // line 4
        echo "    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Commentaires</h1>
    </div>
    <div class=\"col-12 shadow-lg p-2 mb-5 p-lg-5\">
        <nav>
            <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
                <a class=\"nav-item nav-link active\" id=\"nav-comments-tab\" data-toggle=\"tab\" href=\"#nav-comments\"
                   role=\"tab\"
                   aria-controls=\"nav-comments\" aria-selected=\"true\"><h3>Les commentaires</h3></a>
                <a class=\"nav-item nav-link\" id=\"nav-report-tab\" data-toggle=\"tab\" href=\"#nav-report\" role=\"tab\"
                   aria-controls=\"nav-report\" aria-selected=\"false\"><h3>Commentaires signalés</h3></a>
            </div>
        </nav>
        <div class=\"tab-content\" id=\"nav-tabContent\">
            <div class=\"tab-pane fade show active\" id=\"nav-comments\" role=\"tabpanel\" aria-labelledby=\"nav-comments-tab\">
                <div id=\"accordion\">
                    ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["commentoffice"]);
        foreach ($context['_seq'] as $context["_key"] => $context["commentoffice"]) {
            // line 22
            echo "                        <div>
                            <div class=\"card-header\" id=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 26
            echo $this->getAttribute($context["commentoffice"], "pseudo", []);
            echo "</a>
                                    </div>
                                    <div class=\"col-3 visibleEleMD paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 29
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["commentoffice"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</a>
                                    </div>
                                    <div class=\" col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a href=\"index.php?p=post_show&id=";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id_chapter", []), "html", null, true);
            echo "\"
                                           target=\"_blank\">
                                            <button class=\"btn greenLink \">Chapitre</button>
                                        </a>
                                    </div>
                                    <div class=\"col col-sm-4  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-warning font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                                aria-controls=\"collapse";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\" class=\"collapse\"
                                 aria-labelledby=\"";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\" data-parent=\"#accordion\">
                                <div class=\"container-fluide\">
                                    <div class=\"row paddingtext\">
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                            <p>";
            // line 52
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["commentoffice"], "comment", [])), "html", null, true));
            echo "</p>
                                        </div>
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                            <form method=\"post\" action=\"index.php?p=comment_Office\">
                                                <button type=\"submit\"
                                                        class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                        name=\"delete\"
                                                        value=\"";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentoffice"], "id", []), "html", null, true);
            echo "\">
                                                    <a class=\" paddingRL visibleEle \"> Supprimer</a>
                                                    <i data-feather=\"delete\"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['commentoffice'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "                </div>
            </div>
            <div class=\"tab-pane fade active\" id=\"nav-report\" role=\"tabpanel\" aria-labelledby=\"nav-report-tab\">
                <div id=\"accordionR\">
                    ";
        // line 74
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["commentreport"]);
        foreach ($context['_seq'] as $context["_key"] => $context["commentreport"]) {
            // line 75
            echo "                        <div>
                            <div class=\"card-header\" id=\"";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 79
            echo $this->getAttribute($context["commentreport"], "pseudo", []);
            echo "</a>
                                    </div>
                                    <div class=\"col-3 visibleEleMD paddingtext\">
                                        <a class=\"paddingRL\"> ";
            // line 82
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_modify_filter($this->env, $this->getAttribute($context["commentreport"], "date", []), "+1 day"), "m/d/Y"), "html", null, true);
            echo "</a>
                                    </div>
                                    <div class=\" col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a href=\"index.php?p=post_show&id=";
            // line 85
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id_chapter", []), "html", null, true);
            echo "\"
                                           target=\"_blank\">
                                            <button type=\"button\" class=\"btn btn-light greenLink \">Chapitre</button>
                                        </a>
                                    </div>
                                    <div class=\"col col-sm-4  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-danger font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\" aria-expanded=\"true\"
                                                aria-controls=\"collapse";
            // line 94
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse";
            // line 100
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\" class=\"collapse\"
                                 aria-labelledby=\"";
            // line 101
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\"
                                 data-parent=\"#accordionR\">
                                <div class=\"container-fluide\">
                                    <form method=\"post\" action=\"index.php?p=comment_Office\">
                                        <div class=\"row paddingtext\">
                                            <div class=\"col-9\">
                                                <p>";
            // line 107
            echo nl2br(twig_escape_filter($this->env, strip_tags($this->getAttribute($context["commentreport"], "comment", [])), "html", null, true));
            echo "</p>
                                            </div>
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                                <div class=\"col-12 paddingRL\">
                                                    <button type=\"submit\"
                                                            class=\"btn btn-card btn-bg btn-success font-weight-bold \"
                                                            name=\"classify\"
                                                            value=\"";
            // line 114
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\">
                                                        <a class=\" paddingRL visibleEle\">Garder</a>
                                                        <i data-feather=\"check\"></i>
                                                    </button>
                                                </div>
                                                <div class=\"col-12 paddingRL\">
                                                    <button type=\"submit\"
                                                            class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                            name=\"delete\"
                                                            value=\"";
            // line 123
            echo twig_escape_filter($this->env, $this->getAttribute($context["commentreport"], "id", []), "html", null, true);
            echo "\">
                                                        <a class=\" paddingRL visibleEle\"> Supprimer</a>
                                                        <i data-feather=\"delete\"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['commentreport'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 135
        echo "                </div>
            </div>
        </div>
    </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "Admin/Office/officeComment.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  245 => 135,  227 => 123,  215 => 114,  205 => 107,  196 => 101,  192 => 100,  183 => 94,  179 => 93,  168 => 85,  162 => 82,  156 => 79,  150 => 76,  147 => 75,  143 => 74,  137 => 70,  120 => 59,  110 => 52,  103 => 48,  99 => 47,  90 => 41,  86 => 40,  75 => 32,  69 => 29,  63 => 26,  57 => 23,  54 => 22,  50 => 21,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends  \"Layout/layoutdashboard.html.twig\" %}

{% block textarea %}
    <br/>
    <div class=\"col-12 shadow-lg p-4 mb-5  \">
        <h1>Commentaires</h1>
    </div>
    <div class=\"col-12 shadow-lg p-2 mb-5 p-lg-5\">
        <nav>
            <div class=\"nav nav-tabs\" id=\"nav-tab\" role=\"tablist\">
                <a class=\"nav-item nav-link active\" id=\"nav-comments-tab\" data-toggle=\"tab\" href=\"#nav-comments\"
                   role=\"tab\"
                   aria-controls=\"nav-comments\" aria-selected=\"true\"><h3>Les commentaires</h3></a>
                <a class=\"nav-item nav-link\" id=\"nav-report-tab\" data-toggle=\"tab\" href=\"#nav-report\" role=\"tab\"
                   aria-controls=\"nav-report\" aria-selected=\"false\"><h3>Commentaires signalés</h3></a>
            </div>
        </nav>
        <div class=\"tab-content\" id=\"nav-tabContent\">
            <div class=\"tab-pane fade show active\" id=\"nav-comments\" role=\"tabpanel\" aria-labelledby=\"nav-comments-tab\">
                <div id=\"accordion\">
                    {% for commentoffice in commentoffice %}
                        <div>
                            <div class=\"card-header\" id=\"{{ commentoffice.id }}\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> {{ commentoffice.pseudo|raw }}</a>
                                    </div>
                                    <div class=\"col-3 visibleEleMD paddingtext\">
                                        <a class=\"paddingRL\"> {{ commentoffice.date|date_modify ( \"+1 day\" )| date ( \"m/d/Y\"  ) }}</a>
                                    </div>
                                    <div class=\" col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a href=\"index.php?p=post_show&id={{ commentoffice.id_chapter }}\"
                                           target=\"_blank\">
                                            <button class=\"btn greenLink \">Chapitre</button>
                                        </a>
                                    </div>
                                    <div class=\"col col-sm-4  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-warning font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse{{ commentoffice.id }}\" aria-expanded=\"true\"
                                                aria-controls=\"collapse{{ commentoffice.id }}\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse{{ commentoffice.id }}\" class=\"collapse\"
                                 aria-labelledby=\"{{ commentoffice.id }}\" data-parent=\"#accordion\">
                                <div class=\"container-fluide\">
                                    <div class=\"row paddingtext\">
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9 paddingtext\">
                                            <p>{{ commentoffice.comment|striptags|nl2br }}</p>
                                        </div>
                                        <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                            <form method=\"post\" action=\"index.php?p=comment_Office\">
                                                <button type=\"submit\"
                                                        class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                        name=\"delete\"
                                                        value=\"{{ commentoffice.id }}\">
                                                    <a class=\" paddingRL visibleEle \"> Supprimer</a>
                                                    <i data-feather=\"delete\"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
            <div class=\"tab-pane fade active\" id=\"nav-report\" role=\"tabpanel\" aria-labelledby=\"nav-report-tab\">
                <div id=\"accordionR\">
                    {% for commentreport in commentreport %}
                        <div>
                            <div class=\"card-header\" id=\"{{ commentreport.id }}\">
                                <div class=\"mb-0 row justify-content-between\">
                                    <div class=\"col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a class=\"paddingRL\"> {{ commentreport.pseudo|raw }}</a>
                                    </div>
                                    <div class=\"col-3 visibleEleMD paddingtext\">
                                        <a class=\"paddingRL\"> {{ commentreport.date|date_modify ( \"+1 day\" )| date ( \"m/d/Y\"  ) }}</a>
                                    </div>
                                    <div class=\" col col-sm-4 col-md-4 col-lg-2 paddingtext\">
                                        <a href=\"index.php?p=post_show&id={{ commentreport.id_chapter }}\"
                                           target=\"_blank\">
                                            <button type=\"button\" class=\"btn btn-light greenLink \">Chapitre</button>
                                        </a>
                                    </div>
                                    <div class=\"col col-sm-4  col-md-4 col-lg-2 paddingtext\">
                                        <button class=\"btn btn-card btn-danger font-weight-bold collapsed\"
                                                data-toggle=\"collapse\"
                                                data-target=\"#collapse{{ commentreport.id }}\" aria-expanded=\"true\"
                                                aria-controls=\"collapse{{ commentreport.id }}\">
                                            Lire
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div id=\"collapse{{ commentreport.id }}\" class=\"collapse\"
                                 aria-labelledby=\"{{ commentreport.id }}\"
                                 data-parent=\"#accordionR\">
                                <div class=\"container-fluide\">
                                    <form method=\"post\" action=\"index.php?p=comment_Office\">
                                        <div class=\"row paddingtext\">
                                            <div class=\"col-9\">
                                                <p>{{ commentreport.comment|striptags|nl2br }}</p>
                                            </div>
                                            <div class=\"col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 \">
                                                <div class=\"col-12 paddingRL\">
                                                    <button type=\"submit\"
                                                            class=\"btn btn-card btn-bg btn-success font-weight-bold \"
                                                            name=\"classify\"
                                                            value=\"{{ commentreport.id }}\">
                                                        <a class=\" paddingRL visibleEle\">Garder</a>
                                                        <i data-feather=\"check\"></i>
                                                    </button>
                                                </div>
                                                <div class=\"col-12 paddingRL\">
                                                    <button type=\"submit\"
                                                            class=\"btn btn-card btn-danger font-weight-bold  btn-bg\"
                                                            name=\"delete\"
                                                            value=\"{{ commentreport.id }}\">
                                                        <a class=\" paddingRL visibleEle\"> Supprimer</a>
                                                        <i data-feather=\"delete\"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
        </div>
    </div>
    </div>
{% endblock %}
", "Admin/Office/officeComment.html.twig", "C:\\wamp64\\www\\literaryBlog2\\app\\Views\\Admin\\Office\\officeComment.html.twig");
    }
}
