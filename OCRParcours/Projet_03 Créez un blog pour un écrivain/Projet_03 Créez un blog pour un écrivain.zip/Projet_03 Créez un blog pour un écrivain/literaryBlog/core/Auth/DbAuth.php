<?php
/**
 * Created by PhpStorm.
 * User: siegf_000
 * Date: 12/02/2019
 * Time: 11:10
 */

namespace LiteraryCore\Auth;

use LiteraryCore\Controller\AbstractController;

class DBAuth extends AbstractController
{

}