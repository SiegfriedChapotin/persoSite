<?php
/**
 * Created by PhpStorm.
 * Author: siegf_000
 * Date: 14/11/2018
 * Time: 13:51
 */

namespace LiteraryCore\Router;


interface RoutesInterface
{
    public function getRoutes(): array;
}