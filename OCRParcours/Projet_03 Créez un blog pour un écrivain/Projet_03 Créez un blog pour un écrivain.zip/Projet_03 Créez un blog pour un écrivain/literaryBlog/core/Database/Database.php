<?php
/**
 * Created by PhpStorm.
 * Author: siegf_000
 * Date: 11/02/2019
 * Time: 18:17
 */

namespace LiteraryCore\Database;


class Database
{

}