<?php
// datastore=auditqueue;
// created_on=1527251785;
// updated_on=1527251785;
exit(0);
?>
1527251785_8967:"Warning: siegfriedchapotin_wv8fg85k, 90.49.196.1; Plugin deactivated: Sucuri Security - Auditing, Malware Scanner and Hardening (v1.8.16; sucuri-scanner\/sucuri.php)"
