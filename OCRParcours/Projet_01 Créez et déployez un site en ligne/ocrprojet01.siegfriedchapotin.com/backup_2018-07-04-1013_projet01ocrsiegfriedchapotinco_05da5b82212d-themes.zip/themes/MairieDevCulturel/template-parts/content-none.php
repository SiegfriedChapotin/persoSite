<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WP_Bootstrap_Starter
 */

?>

<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title"><?php esc_html_e( 'Aucun résultat trouvé', 'wp-bootstrap-starter' ); ?></h1>
	</header><!-- .page-header -->

	<div class="page-content">
		<?php
		if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

			<p><?php printf( wp_kses( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'wp-bootstrap-starter' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

		<?php elseif ( is_search() ) : ?>

			<p><?php esc_html_e( 'Désolé, mais rien ne correspond à vos critères de recherche. Veuillez réessayer avec d\'autres mots-clés. ', 'wp-bootstrap-starter' ); ?></p>
			<?php
				get_search_form();

		else : ?>

			<p><?php esc_html_e( ' 	Il semble que nous ne pouvons pas trouver ce que vous recherchez. ', 'wp-bootstrap-starter' ); ?></p>
		
			<br/> 
			
			<?php
				get_search_form();

		endif; ?>
	</div><!-- .page-content -->
			
		<h1 class="page-title" style="text-align:center"><?php esc_html_e( 'Une autre recherche ? ', 'wp-bootstrap-starter' ); ?></h1>
		<p style="text-align:center"><?php esc_html_e( 'Il y a tellement de choses à découvrir à Nantes !', 'wp-bootstrap-starter' ); ?></p>
			
		<p style="text-align:center"><a><img style="width:50%" src="https://projet01ocr.siegfriedchapotin.com/wp-content/uploads/personaje-de-dibujos-animados-del-monitor-de-computadora-40164128.png"/></a></p>
</section><!-- .no-results -->
