<strong><?php _e('Premium WordPress Themes from WP Maintenance Mode authors!', $this->plugin_slug); ?></strong>

<br /><br />
	<?php _e('We hope you like the WP Maintenance Mode plugin! Now you can buy WordPress Themes directly from us on ThemeForest. We\'re StrictThemes and we create best designed and coded WordPress Themes.', $this->plugin_slug); ?>
<br /><br />

<a class="button button-primary" href="https://themeforest.net/user/strictthemes/portfolio?utf8=%E2%9C%93&order_by=sales&ref=StrictThemes" target="_blank">
	<?php _e('See our WordPress Themes!', $this->plugin_slug); ?>
</a>