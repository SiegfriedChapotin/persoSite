<?php defined( 'ABSPATH' ) or exit; ?>

<ul>
	<li><a href="http://docs.getshortcodes.com/article/56-how-to-install-add-on" target="_blank"><?php _e( 'How to install add-on', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="http://docs.getshortcodes.com/article/59-how-to-get-updates" target="_blank"><?php _e( 'How to get updates', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="http://docs.getshortcodes.com/article/58-how-to-activate-license-key" target="_blank"><?php _e( 'How to activate license key', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="http://docs.getshortcodes.com/collection/24-add-ons" target="_blank"><?php _e( 'Full add-ons documentation', 'shortcodes-ultimate' ); ?></a></li>
</ul>
