LANGUAGE TRANSLATION FILES FOR IMSANITY
---------------------------------------

If you are interested in creating a language translation for Imsanity then
you're in the right place!  We would love your help, and you
can get started translating Imsanity at https://translate.wordpress.org/projects/wp-plugins/imsanity

Anything you can do to help is greatly appreciated and allows
Imsanity to be more easily used by people all over the world.

Thank you for supporting Imsanity and all free software!
